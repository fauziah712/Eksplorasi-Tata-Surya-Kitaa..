import React, { useState } from 'react';
import { PlanetData } from '../types/solar';
import { PLANETS_DATA } from '../data/planetsData';
import {
  ChevronLeft,
  ChevronRight,
  X,
  Compass,
  Thermometer,
  Ruler,
  Clock,
  Orbit,
  Shield,
  Sparkles,
  Droplet,
  Wind,
  Radio,
  RotateCw,
  Globe2,
} from 'lucide-react';
import { cosmicAudio } from '../utils/audio';

interface PlanetInfoModalProps {
  planet: PlanetData;
  onClose: () => void;
  onSelectPlanet: (planet: PlanetData) => void;
  onResetView: () => void;
  soundEnabled: boolean;
}

type TabType = 'karakteristik' | 'kehidupan' | 'fakta';

export const PlanetInfoModal: React.FC<PlanetInfoModalProps> = ({
  planet,
  onClose,
  onSelectPlanet,
  onResetView,
  soundEnabled,
}) => {
  const [activeTab, setActiveTab] = useState<TabType>('karakteristik');

  const currentIndex = PLANETS_DATA.findIndex((p) => p.id === planet.id);
  const prevPlanet = PLANETS_DATA[(currentIndex - 1 + PLANETS_DATA.length) % PLANETS_DATA.length];
  const nextPlanet = PLANETS_DATA[(currentIndex + 1) % PLANETS_DATA.length];

  const handlePrev = () => {
    if (soundEnabled) {
      cosmicAudio.playPlanetSelect(prevPlanet.orderFromSun);
    }
    onSelectPlanet(prevPlanet);
  };

  const handleNext = () => {
    if (soundEnabled) {
      cosmicAudio.playPlanetSelect(nextPlanet.orderFromSun);
    }
    onSelectPlanet(nextPlanet);
  };

  const handleTabChange = (tab: TabType) => {
    if (soundEnabled) cosmicAudio.playClick(960);
    setActiveTab(tab);
  };

  return (
    <aside
      className="fixed top-16 bottom-20 right-0 sm:right-4 w-full sm:w-[460px] max-w-full z-30 flex flex-col bg-slate-950/85 backdrop-blur-xl border-l sm:border border-cyan-500/25 sm:rounded-2xl shadow-2xl shadow-cyan-950/50 text-slate-100 overflow-hidden transition-all duration-300 animate-in fade-in slide-in-from-right-6"
      aria-label="Panel Informasi Planet"
    >
      {/* Header Bar */}
      <div className="p-4 sm:p-5 border-b border-cyan-500/20 bg-gradient-to-r from-slate-900/90 to-slate-950/90">
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono tracking-wider text-cyan-400 font-semibold">
              {planet.orderFromSun === 0
                ? 'PUSAT TATA SURYA'
                : `PLANET KE-${planet.orderFromSun}`}
            </span>
            <span className="text-slate-600">·</span>
            <span className="text-xs text-slate-400">{planet.type}</span>
          </div>

          <button
            onClick={() => {
              if (soundEnabled) cosmicAudio.playClick(600);
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800/80 transition-colors"
            title="Tutup Panel"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <h2 className="text-2xl sm:text-3xl font-bold tracking-tight text-white flex items-center gap-2">
          {planet.indonesianName}
          {planet.name !== planet.indonesianName && (
            <span className="text-sm font-normal text-slate-400 italic">({planet.name})</span>
          )}
        </h2>
        <p className="text-xs sm:text-sm text-cyan-300/90 mt-0.5">{planet.tagline}</p>
      </div>

      {/* Segmented Tab Controls */}
      <div className="flex p-1.5 mx-4 mt-3 bg-slate-900/90 rounded-xl border border-slate-800 text-xs font-medium shrink-0">
        <button
          onClick={() => handleTabChange('karakteristik')}
          className={`flex-1 py-1.5 px-2 rounded-lg transition-colors whitespace-nowrap text-center ${
            activeTab === 'karakteristik'
              ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Karakteristik
        </button>
        <button
          onClick={() => handleTabChange('kehidupan')}
          className={`flex-1 py-1.5 px-2 rounded-lg transition-colors whitespace-nowrap text-center ${
            activeTab === 'kehidupan'
              ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Potensi Hidup
        </button>
        <button
          onClick={() => handleTabChange('fakta')}
          className={`flex-1 py-1.5 px-2 rounded-lg transition-colors whitespace-nowrap text-center ${
            activeTab === 'fakta'
              ? 'bg-cyan-500 text-slate-950 font-bold shadow-md shadow-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200'
          }`}
        >
          Manfaat & Fakta
        </button>
      </div>

      {/* Tab Content Body (Scrollable) */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
        {/* TAB 1: KARAKTERISTIK UTAMA */}
        {activeTab === 'karakteristik' && (
          <div className="space-y-4">
            <p className="text-xs sm:text-sm leading-relaxed text-slate-300 bg-slate-900/50 p-3 rounded-xl border border-slate-800">
              {planet.overview}
            </p>

            {/* Metrics Grid */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                  <Ruler className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Diameter Fisik</span>
                </div>
                <div className="text-sm font-semibold font-mono text-white">
                  {planet.diameterFormatted}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                  <Compass className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Jarak ke Surya</span>
                </div>
                <div className="text-sm font-semibold font-mono text-white">
                  {planet.distanceFormatted}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                  <Thermometer className="w-3.5 h-3.5 text-amber-400" />
                  <span>Suhu Rata-rata</span>
                </div>
                <div className="text-sm font-semibold font-mono text-white">
                  {planet.surfaceTempCelsius}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                  <RotateCw className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Periode Rotasi (1 Hari)</span>
                </div>
                <div className="text-sm font-semibold font-mono text-white">
                  {planet.rotationPeriod}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                  <Orbit className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Periode Revolusi (1 Thn)</span>
                </div>
                <div className="text-sm font-semibold font-mono text-white">
                  {planet.revolutionPeriod}
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-900/70 border border-slate-800">
                <div className="flex items-center gap-1.5 text-xs text-slate-400 mb-1">
                  <Globe2 className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Satelit / Bulan</span>
                </div>
                <div className="text-sm font-semibold font-mono text-white">
                  {planet.naturalSatellitesCount} Satelit Alami
                </div>
              </div>
            </div>

            {/* Komposisi Unsur */}
            <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800">
              <h3 className="text-xs font-semibold text-cyan-300 uppercase tracking-wider mb-2">
                Komposisi Utama
              </h3>
              <div className="flex flex-wrap gap-1.5">
                {planet.composition.map((item, idx) => (
                  <span
                    key={idx}
                    className="text-xs px-2.5 py-1 rounded-md bg-slate-800 text-slate-200 border border-slate-700/60"
                  >
                    {item}
                  </span>
                ))}
              </div>
            </div>

            {/* Gravitasi & Kemiringan Sumbu */}
            <div className="flex items-center justify-between text-xs text-slate-400 px-1 font-mono">
              <span>Gravitasi: <strong className="text-slate-200">{planet.gravityMps2} m/s²</strong></span>
              <span>Kemiringan Sumbu: <strong className="text-slate-200">{planet.axialTiltDeg}°</strong></span>
            </div>
          </div>
        )}

        {/* TAB 2: POTENSI KEHIDUPAN */}
        {activeTab === 'kehidupan' && (
          <div className="space-y-3.5">
            {/* Status Kelayakan Banner */}
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
              <div className="text-xs text-slate-400 mb-1">Status Kelayakan Huni:</div>
              <div className="text-base font-bold text-cyan-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                {planet.lifePotential.status}
              </div>
              <p className="text-xs text-slate-300 mt-2 leading-relaxed">
                {planet.lifePotential.summary}
              </p>
            </div>

            {/* Atmosfer */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-cyan-400">
                <Wind className="w-4 h-4" />
                <span>Kondisi Atmosfer & Tekanan</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {planet.lifePotential.atmosphere}
              </p>
            </div>

            {/* Ketersediaan Air */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-cyan-400">
                <Droplet className="w-4 h-4" />
                <span>Ketersediaan Air (H₂O)</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {planet.lifePotential.waterPresence}
              </p>
            </div>

            {/* Radiasi & Medan Magnet */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400">
                <Radio className="w-4 h-4" />
                <span>Radiasi Kosmik & Perlindungan Magnetik</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {planet.lifePotential.radiationAndMagnetism}
              </p>
            </div>

            {/* Faktor Pendukung/Penghambat Utama */}
            <div className="p-3 rounded-xl bg-slate-900/60 border border-slate-800/80 space-y-1">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
                <Shield className="w-4 h-4" />
                <span>Faktor Utama Kelayakan Huni</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {planet.lifePotential.mainObstacleOrSupport}
              </p>
            </div>
          </div>
        )}

        {/* TAB 3: MANFAAT & FAKTA MENARIK */}
        {activeTab === 'fakta' && (
          <div className="space-y-3.5">
            {/* Peran Kestabilan Sistem */}
            <div className="p-3.5 rounded-xl bg-slate-900/90 border border-slate-800">
              <div className="flex items-center gap-2 text-xs font-bold text-cyan-400 uppercase tracking-wider mb-1.5">
                <Shield className="w-4 h-4" />
                <span>Peran Kestabilan Tata Surya</span>
              </div>
              <p className="text-xs sm:text-sm text-slate-200 leading-relaxed">
                {planet.benefitsAndFacts.solarSystemRole}
              </p>
            </div>

            {/* Fungsi Medan Magnet */}
            <div className="p-3.5 rounded-xl bg-slate-900/70 border border-slate-800">
              <div className="flex items-center gap-2 text-xs font-bold text-amber-300 uppercase tracking-wider mb-1.5">
                <Radio className="w-4 h-4" />
                <span>Fungsi Medan Magnetik</span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                {planet.benefitsAndFacts.magneticFieldFunction}
              </p>
            </div>

            {/* Fakta Unik Sains */}
            <div className="space-y-2">
              <div className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-1">
                Fakta Unik Sains
              </div>
              {planet.benefitsAndFacts.uniqueFacts.map((fact, fIdx) => (
                <div
                  key={fIdx}
                  className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 text-xs sm:text-sm text-slate-200 flex items-start gap-2.5"
                >
                  <span className="font-mono text-cyan-400 font-bold shrink-0">
                    0{fIdx + 1}.
                  </span>
                  <span className="leading-relaxed">{fact}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Footer Navigation: Sebelumnya, Selanjutnya, Tampilan Luar Angkasa */}
      <div className="p-3 sm:p-4 border-t border-cyan-500/20 bg-slate-950/95 flex items-center justify-between gap-2 shrink-0">
        <button
          onClick={handlePrev}
          className="flex items-center gap-1 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700/60 rounded-xl transition-colors"
          title={`Ke ${prevPlanet.indonesianName}`}
        >
          <ChevronLeft className="w-4 h-4" />
          <span className="hidden xs:inline">{prevPlanet.indonesianName}</span>
        </button>

        <button
          onClick={() => {
            if (soundEnabled) cosmicAudio.playClick(720);
            onResetView();
          }}
          className="flex-1 px-3 py-2 text-xs font-semibold text-cyan-300 hover:text-white bg-cyan-950/50 hover:bg-cyan-900/60 border border-cyan-500/30 rounded-xl transition-colors text-center"
        >
          Tampilan Luar Angkasa
        </button>

        <button
          onClick={handleNext}
          className="flex items-center gap-1 px-3 py-2 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-700/60 rounded-xl transition-colors"
          title={`Ke ${nextPlanet.indonesianName}`}
        >
          <span className="hidden xs:inline">{nextPlanet.indonesianName}</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
};
