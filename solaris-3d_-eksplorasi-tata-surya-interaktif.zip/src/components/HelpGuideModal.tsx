import React from 'react';
import { X, MousePointer, Hand, ZoomIn, Eye, Trophy, Scale } from 'lucide-react';
import { cosmicAudio } from '../utils/audio';

interface HelpGuideModalProps {
  onClose: () => void;
  soundEnabled: boolean;
}

export const HelpGuideModal: React.FC<HelpGuideModalProps> = ({ onClose, soundEnabled }) => {
  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/85 backdrop-blur-md flex items-center justify-center p-4"
      role="dialog"
      aria-label="Panduan Kontrol dan Eksplorasi"
    >
      <div className="bg-slate-900 border border-cyan-500/30 rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl shadow-cyan-950/50 text-slate-200 animate-in fade-in zoom-in-95">
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <div className="text-xs font-mono text-cyan-400 font-semibold uppercase">
              Petunjuk Navigasi & Eksplorasi
            </div>
            <h3 className="text-xl sm:text-2xl font-bold text-white">
              Cara Menggunakan Solaris 3D
            </h3>
          </div>
          <button
            onClick={() => {
              if (soundEnabled) cosmicAudio.playClick(600);
              onClose();
            }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4 text-xs sm:text-sm">
          {/* Mouse / Desktop controls */}
          <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
            <div className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <MousePointer className="w-4 h-4 text-cyan-400" />
              <span>Kontrol Mouse (Komputer / Laptop)</span>
            </div>
            <ul className="space-y-1 text-slate-300">
              <li>• <strong>Klik Kiri & Geser:</strong> Memutar sudut pandang 360° mengelilingi pusat.</li>
              <li>• <strong>Scroll Roda Mouse:</strong> Zoom In mendekat / Zoom Out menjauh.</li>
              <li>• <strong>Klik Kanan & Geser:</strong> Menggeser (Pan) posisi kamera luar angkasa.</li>
              <li>• <strong>Klik Planet / Label:</strong> Kamera meluncur otomatis mendekati planet terpilih.</li>
            </ul>
          </div>

          {/* Touch / Mobile controls */}
          <div className="p-3.5 rounded-2xl bg-slate-950/60 border border-slate-800 space-y-2">
            <div className="text-xs font-bold text-cyan-300 uppercase tracking-wider flex items-center gap-1.5">
              <Hand className="w-4 h-4 text-cyan-400" />
              <span>Kontrol Sentuhan (Smartphone / Tablet)</span>
            </div>
            <ul className="space-y-1 text-slate-300">
              <li>• <strong>Geser 1 Jari:</strong> Memutar sudut pandang rotasi 360°.</li>
              <li>• <strong>Cubit 2 Jari (Pinch):</strong> Zoom in dan zoom out.</li>
              <li>• <strong>Ketuk Planet:</strong> Membuka panel detail sains dan karakteristik.</li>
            </ul>
          </div>

          {/* Features highlight */}
          <div className="grid grid-cols-2 gap-3 pt-1">
            <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-amber-400 mb-1">
                <Scale className="w-3.5 h-3.5" />
                <span>Bandingkan Ukuran</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Lihat skala proporsi nyata perbandingan diameter dan volume planet dengan Bumi.
              </p>
            </div>

            <div className="p-3 rounded-xl bg-slate-950/40 border border-slate-800">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400 mb-1">
                <Trophy className="w-3.5 h-3.5" />
                <span>Kuis & Evaluasi</span>
              </div>
              <p className="text-[11px] text-slate-400">
                Uji pemahamanmu, tebak visual planet, raih Nilai 100 dengan selebrasi confetti!
              </p>
            </div>
          </div>
        </div>

        <button
          onClick={() => {
            if (soundEnabled) cosmicAudio.playClick(700);
            onClose();
          }}
          className="w-full py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-colors shadow-lg shadow-cyan-500/20"
        >
          Mengerti, Mulai Jelajahi Kosmos!
        </button>
      </div>
    </div>
  );
};
