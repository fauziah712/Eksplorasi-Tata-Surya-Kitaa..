import React, { useState } from 'react';
import confetti from 'canvas-confetti';
import { QUIZ_QUESTIONS } from '../data/quizData';
import { QuizQuestion, PlanetData } from '../types/solar';
import { PLANETS_DATA } from '../data/planetsData';
import {
  X,
  Trophy,
  CheckCircle2,
  XCircle,
  HelpCircle,
  RotateCcw,
  ArrowRight,
  Sparkles,
  Award,
  Layers,
} from 'lucide-react';
import { cosmicAudio } from '../utils/audio';

interface QuizModalProps {
  onClose: () => void;
  onExplorePlanetIn3D?: (planet: PlanetData) => void;
  soundEnabled: boolean;
}

export const QuizModal: React.FC<QuizModalProps> = ({
  onClose,
  onExplorePlanetIn3D,
  soundEnabled,
}) => {
  const [filterType, setFilterType] = useState<'all' | 'guess-planet' | 'multiple-choice'>('all');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [isAnswered, setIsAnswered] = useState<boolean>(false);
  const [correctCount, setCorrectCount] = useState<number>(0);
  const [perfectScoreAchieved, setPerfectScoreAchieved] = useState<boolean>(false);
  const [isCompleted, setIsCompleted] = useState<boolean>(false);

  const activeQuestions = QUIZ_QUESTIONS.filter((q) => {
    if (filterType === 'guess-planet') return q.type === 'guess-planet';
    if (filterType === 'multiple-choice') return q.type === 'multiple-choice';
    return true;
  });

  const currentQuestion: QuizQuestion = activeQuestions[currentIndex] || activeQuestions[0];

  const handleSelectOption = (idx: number) => {
    if (isAnswered) return;
    setSelectedOption(idx);
    setIsAnswered(true);

    const isCorrect = idx === currentQuestion.correctIndex;

    if (isCorrect) {
      setCorrectCount((prev) => prev + 1);
      setPerfectScoreAchieved(true);
      if (soundEnabled) cosmicAudio.playCorrect();

      // Trigger spectacular confetti animation
      confetti({
        particleCount: 110,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#38bdf8', '#fbbf24', '#f43f5e', '#34d399', '#a855f7'],
      });
    } else {
      setPerfectScoreAchieved(false);
      if (soundEnabled) cosmicAudio.playWrong();
    }
  };

  const handleRetryQuestion = () => {
    if (soundEnabled) cosmicAudio.playClick(750);
    setSelectedOption(null);
    setIsAnswered(false);
    setPerfectScoreAchieved(false);
  };

  const handleNext = () => {
    if (soundEnabled) cosmicAudio.playClick(850);
    if (currentIndex + 1 < activeQuestions.length) {
      setCurrentIndex((prev) => prev + 1);
      setSelectedOption(null);
      setIsAnswered(false);
      setPerfectScoreAchieved(false);
    } else {
      setIsCompleted(true);
    }
  };

  const handleResetQuiz = () => {
    if (soundEnabled) cosmicAudio.playClick(650);
    setCurrentIndex(0);
    setSelectedOption(null);
    setIsAnswered(false);
    setCorrectCount(0);
    setPerfectScoreAchieved(false);
    setIsCompleted(false);
  };

  // Find target planet if guess mode
  const targetPlanet = currentQuestion.targetPlanetId
    ? PLANETS_DATA.find((p) => p.id === currentQuestion.targetPlanetId)
    : null;

  return (
    <div
      className="fixed inset-0 z-40 bg-slate-950/90 backdrop-blur-xl flex flex-col p-4 sm:p-6 overflow-y-auto"
      role="dialog"
      aria-label="Kuis Evaluasi Tata Surya"
    >
      {/* Header Bar */}
      <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20 max-w-4xl mx-auto w-full">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 font-semibold mb-1">
            <Trophy className="w-4 h-4 text-amber-400" />
            <span>MODUL EVALUASI & KUIS INTERAKTIF</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white">
            Uji Pemahaman Astronomi Tata Surya
          </h2>
        </div>

        <button
          onClick={() => {
            if (soundEnabled) cosmicAudio.playClick(600);
            onClose();
          }}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title="Tutup Kuis"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="max-w-4xl mx-auto w-full py-6 flex-1 flex flex-col justify-center">
        {/* Category Filters */}
        {!isCompleted && (
          <div className="flex items-center justify-between gap-2 mb-6 flex-wrap">
            <div className="flex items-center gap-1.5 p-1 bg-slate-900/90 rounded-xl border border-slate-800 text-xs font-medium">
              <button
                onClick={() => {
                  setFilterType('all');
                  handleResetQuiz();
                }}
                className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                  filterType === 'all'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Semua Soal ({QUIZ_QUESTIONS.length})
              </button>
              <button
                onClick={() => {
                  setFilterType('guess-planet');
                  handleResetQuiz();
                }}
                className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                  filterType === 'guess-planet'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Tebak Planet 3D
              </button>
              <button
                onClick={() => {
                  setFilterType('multiple-choice');
                  handleResetQuiz();
                }}
                className={`px-3 py-1.5 rounded-lg transition-colors whitespace-nowrap ${
                  filterType === 'multiple-choice'
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                Pilihan Ganda Materi
              </button>
            </div>

            {/* Question Progress */}
            <div className="text-xs font-mono text-slate-400">
              Soal <strong className="text-cyan-400">{currentIndex + 1}</strong> dari{' '}
              {activeQuestions.length}
            </div>
          </div>
        )}

        {/* COMPLETION REPORT */}
        {isCompleted ? (
          <div className="p-8 sm:p-10 rounded-3xl bg-slate-900/80 border border-cyan-500/30 text-center space-y-6 max-w-xl mx-auto shadow-2xl">
            <div className="w-20 h-20 rounded-full bg-gradient-to-tr from-amber-500 to-cyan-400 p-0.5 mx-auto flex items-center justify-center shadow-lg shadow-cyan-500/20">
              <div className="w-full h-full bg-slate-950 rounded-full flex items-center justify-center">
                <Award className="w-10 h-10 text-amber-400" />
              </div>
            </div>

            <div>
              <div className="text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider mb-1">
                Laporan Evaluasi Siswa
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold text-white">
                Selamat! Evaluasi Selesai!
              </h3>
              <p className="text-sm text-slate-300 mt-2">
                Kamu telah menyelesaikan seluruh paket tantangan sains tata surya ini dengan sangat baik.
              </p>
            </div>

            {/* Score Showcase */}
            <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 flex items-center justify-around">
              <div>
                <div className="text-xs text-slate-400">Total Soal Dijawab</div>
                <div className="text-2xl font-bold font-mono text-white">
                  {activeQuestions.length}
                </div>
              </div>
              <div className="w-px h-10 bg-slate-800" />
              <div>
                <div className="text-xs text-slate-400">Gelar Kelulusan</div>
                <div className="text-lg font-bold text-amber-400">
                  {correctCount >= activeQuestions.length * 0.8
                    ? 'Astronom Utama 🌟'
                    : 'Penjelajah Kosmos 🚀'}
                </div>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={handleResetQuiz}
                className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-2 transition-colors"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Ulangi Evaluasi</span>
              </button>
              <button
                onClick={onClose}
                className="px-6 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-colors shadow-lg shadow-cyan-500/30"
              >
                Kembali ke Ruang 3D
              </button>
            </div>
          </div>
        ) : (
          /* ACTIVE QUESTION CARD */
          <div className="p-6 sm:p-8 rounded-3xl bg-slate-900/80 border border-slate-800 shadow-2xl space-y-6">
            {/* Question Type & Difficulty */}
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono px-2.5 py-1 rounded-md bg-cyan-950 text-cyan-400 border border-cyan-800/60 font-semibold">
                  {currentQuestion.type === 'guess-planet'
                    ? 'Tebak Planet 3D'
                    : 'Pilihan Ganda Sains'}
                </span>
                <span className="text-xs text-slate-400">
                  Tingkat: {currentQuestion.difficulty}
                </span>
              </div>

              {perfectScoreAchieved && (
                <div className="flex items-center gap-1.5 px-3 py-1 bg-emerald-500/20 border border-emerald-500/40 rounded-full text-emerald-300 text-xs font-bold animate-bounce">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>NILAI 100!</span>
                </div>
              )}
            </div>

            {/* Question Content */}
            <div className="space-y-3">
              <h3 className="text-xl sm:text-2xl font-bold text-white leading-snug">
                {currentQuestion.question}
              </h3>

              {/* Clues if guess planet */}
              {currentQuestion.clues && (
                <div className="p-4 rounded-2xl bg-slate-950/60 border border-slate-800/80 space-y-2">
                  <div className="text-xs font-bold text-cyan-400 uppercase tracking-wider flex items-center gap-1.5">
                    <HelpCircle className="w-3.5 h-3.5" />
                    <span>Petunjuk Ciri Fisik Kosmik:</span>
                  </div>
                  <ul className="space-y-1.5 text-xs sm:text-sm text-slate-300">
                    {currentQuestion.clues.map((clue, cIdx) => (
                      <li key={cIdx} className="flex items-start gap-2">
                        <span className="text-cyan-400 font-mono font-bold">•</span>
                        <span>{clue}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>

            {/* Multiple Choice Options */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
              {currentQuestion.options.map((opt, oIdx) => {
                const isSelected = selectedOption === oIdx;
                const isCorrect = oIdx === currentQuestion.correctIndex;

                let btnStyle =
                  'bg-slate-950/60 hover:bg-slate-800 text-slate-200 border-slate-800 hover:border-cyan-500/40';

                if (isAnswered) {
                  if (isCorrect) {
                    btnStyle =
                      'bg-emerald-950/60 border-emerald-500 text-emerald-200 ring-2 ring-emerald-500/40 font-semibold';
                  } else if (isSelected && !isCorrect) {
                    btnStyle =
                      'bg-rose-950/60 border-rose-500 text-rose-200 ring-2 ring-rose-500/40';
                  } else {
                    btnStyle = 'opacity-40 bg-slate-950/40 border-slate-800 text-slate-400';
                  }
                }

                return (
                  <button
                    key={oIdx}
                    onClick={() => handleSelectOption(oIdx)}
                    disabled={isAnswered}
                    className={`p-4 rounded-2xl border text-left text-xs sm:text-sm transition-all duration-200 flex items-center justify-between gap-3 ${btnStyle}`}
                  >
                    <div className="flex items-center gap-3">
                      <span className="w-6 h-6 rounded-lg bg-slate-900 border border-slate-700 flex items-center justify-center font-mono text-xs text-slate-300 shrink-0">
                        {String.fromCharCode(65 + oIdx)}
                      </span>
                      <span className="leading-snug">{opt}</span>
                    </div>

                    {isAnswered && isCorrect && (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
                    )}
                    {isAnswered && isSelected && !isCorrect && (
                      <XCircle className="w-5 h-5 text-rose-400 shrink-0" />
                    )}
                  </button>
                );
              })}
            </div>

            {/* Pedagogical Feedback Banner (Shows on Answer) */}
            {isAnswered && (
              <div
                className={`p-4 rounded-2xl border space-y-3 transition-all duration-300 animate-in fade-in ${
                  selectedOption === currentQuestion.correctIndex
                    ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-100'
                    : 'bg-rose-950/30 border-rose-500/40 text-rose-100'
                }`}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-bold text-sm sm:text-base">
                    {selectedOption === currentQuestion.correctIndex ? (
                      <>
                        <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                        <span>Jawaban Kamu Benar! Mendapat Nilai 100! 🌟</span>
                      </>
                    ) : (
                      <>
                        <XCircle className="w-5 h-5 text-rose-400" />
                        <span>Jawaban Kurang Tepat, Mari Pelajari Pembahasannya!</span>
                      </>
                    )}
                  </div>
                </div>

                <p className="text-xs sm:text-sm leading-relaxed text-slate-200">
                  {currentQuestion.explanation}
                </p>

                {/* Action Buttons: Retry or Next */}
                <div className="flex items-center justify-end gap-3 pt-2">
                  {selectedOption !== currentQuestion.correctIndex && (
                    <button
                      onClick={handleRetryQuestion}
                      className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Coba Ulangi Soal Ini</span>
                    </button>
                  )}

                  {targetPlanet && onExplorePlanetIn3D && (
                    <button
                      onClick={() => {
                        onExplorePlanetIn3D(targetPlanet);
                        onClose();
                      }}
                      className="px-4 py-2 rounded-xl bg-cyan-950 hover:bg-cyan-900 border border-cyan-500/40 text-cyan-300 text-xs font-semibold flex items-center gap-1.5 transition-colors"
                    >
                      <Layers className="w-3.5 h-3.5" />
                      <span>Lihat {targetPlanet.indonesianName} di 3D</span>
                    </button>
                  )}

                  <button
                    onClick={handleNext}
                    className="px-5 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold flex items-center gap-1.5 transition-colors shadow-lg shadow-cyan-500/30"
                  >
                    <span>
                      {currentIndex + 1 < activeQuestions.length
                        ? 'Tantangan Berikutnya'
                        : 'Lihat Hasil Akhir'}
                    </span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
