import React from 'react';
import { PlanetData } from '../types/solar';
import { PLANETS_DATA } from '../data/planetsData';
import { Globe, Sun } from 'lucide-react';
import { cosmicAudio } from '../utils/audio';

interface PlanetQuickNavProps {
  selectedPlanet: PlanetData | null;
  onSelectPlanet: (planet: PlanetData | null) => void;
  soundEnabled: boolean;
}

export const PlanetQuickNav: React.FC<PlanetQuickNavProps> = ({
  selectedPlanet,
  onSelectPlanet,
  soundEnabled,
}) => {
  const handleSelect = (planet: PlanetData) => {
    if (soundEnabled) {
      cosmicAudio.playPlanetSelect(planet.orderFromSun);
    }
    onSelectPlanet(planet);
  };

  return (
    <nav
      aria-label="Bilah Navigasi Cepat Planet"
      className="fixed bottom-3 left-1/2 -translate-x-1/2 z-20 max-w-[95vw] overflow-x-auto py-1.5 px-2 bg-slate-950/80 backdrop-blur-md border border-cyan-500/25 rounded-2xl shadow-xl shadow-black/60 flex items-center gap-1.5 scrollbar-none"
    >
      <button
        onClick={() => {
          if (soundEnabled) cosmicAudio.playClick(720);
          onSelectPlanet(null);
        }}
        className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-all flex items-center gap-1.5 ${
          selectedPlanet === null
            ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/30 font-bold'
            : 'text-slate-300 hover:text-white hover:bg-slate-900/80'
        }`}
      >
        <Globe className="w-3.5 h-3.5" />
        <span>Tata Surya</span>
      </button>

      <div className="w-px h-5 bg-slate-800 shrink-0" />

      {PLANETS_DATA.map((planet) => {
        const isSelected = selectedPlanet?.id === planet.id;
        return (
          <button
            key={planet.id}
            onClick={() => handleSelect(planet)}
            className={`px-2.5 py-1.5 rounded-xl text-xs whitespace-nowrap transition-all flex items-center gap-1.5 ${
              isSelected
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/50 shadow-sm font-semibold scale-105'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            {/* Color dot or Sun Icon */}
            {planet.id === 'sun' ? (
              <Sun className="w-3.5 h-3.5 text-amber-400 animate-spin-slow" />
            ) : (
              <span
                className="w-2.5 h-2.5 rounded-full inline-block shrink-0 shadow-sm"
                style={{ backgroundColor: planet.color }}
              />
            )}
            <span>{planet.indonesianName}</span>
          </button>
        );
      })}
    </nav>
  );
};
