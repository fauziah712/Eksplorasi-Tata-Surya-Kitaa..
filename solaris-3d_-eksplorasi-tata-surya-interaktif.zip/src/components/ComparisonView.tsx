import React, { useState } from 'react';
import { PLANETS_DATA } from '../data/planetsData';
import { PlanetData } from '../types/solar';
import { X, Scale, Info, ArrowRight } from 'lucide-react';
import { cosmicAudio } from '../utils/audio';

interface ComparisonViewProps {
  onClose: () => void;
  onSelectPlanet: (planet: PlanetData) => void;
  soundEnabled: boolean;
}

export const ComparisonView: React.FC<ComparisonViewProps> = ({
  onClose,
  onSelectPlanet,
  soundEnabled,
}) => {
  const [targetPlanetId, setTargetPlanetId] = useState<string>('jupiter');

  const selectedPlanet = PLANETS_DATA.find((p) => p.id === targetPlanetId) || PLANETS_DATA[5];
  const earth = PLANETS_DATA.find((p) => p.id === 'earth')!;

  const ratioVsEarth = (selectedPlanet.diameterKm / earth.diameterKm).toFixed(2);
  const volumeRatio = Math.round(
    Math.pow(selectedPlanet.diameterKm / earth.diameterKm, 3)
  );

  return (
    <div
      className="fixed inset-0 z-40 bg-slate-950/90 backdrop-blur-xl flex flex-col p-4 sm:p-6 overflow-y-auto"
      role="dialog"
      aria-label="Perbandingan Skala Planet"
    >
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-cyan-500/20 max-w-6xl mx-auto w-full">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 font-semibold mb-1">
            <Scale className="w-4 h-4" />
            <span>LABORATORIUM SKALA ASTRONOMI</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-white">
            Perbandingan Ukuran Planet Tata Surya
          </h2>
          <p className="text-xs sm:text-sm text-slate-400 mt-0.5">
            Pelajari skala nyata ukuran diameter, volume perbandingan terhadap Bumi, dan massa planet.
          </p>
        </div>

        <button
          onClick={() => {
            if (soundEnabled) cosmicAudio.playClick(600);
            onClose();
          }}
          className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          title="Tutup Perbandingan"
        >
          <X className="w-6 h-6" />
        </button>
      </div>

      <div className="max-w-6xl mx-auto w-full py-6 space-y-8 flex-1">
        {/* Visual Scale Row (Planet Circles side-by-side proportionally) */}
        <div className="p-4 sm:p-6 rounded-2xl bg-slate-900/60 border border-cyan-500/20 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-cyan-300 uppercase tracking-wider">
              Visualisasi Skala Diameter Relatif
            </h3>
            <span className="text-xs text-slate-400">
              *Matahari diperkecil 5x agar muat di layar
            </span>
          </div>

          <div className="overflow-x-auto pb-4 pt-6">
            <div className="flex items-end justify-between min-w-[700px] gap-4 px-2">
              {PLANETS_DATA.map((planet) => {
                // Approximate visual pixel diameter
                let pixelSize = Math.max(14, (planet.diameterKm / 139820) * 110);
                if (planet.id === 'sun') pixelSize = 130; // Scaled down for viewport

                const isTarget = planet.id === targetPlanetId;

                return (
                  <button
                    key={planet.id}
                    onClick={() => {
                      if (soundEnabled) cosmicAudio.playClick(800);
                      setTargetPlanetId(planet.id);
                    }}
                    className={`flex flex-col items-center gap-3 group transition-transform ${
                      isTarget ? 'scale-105' : 'opacity-80 hover:opacity-100'
                    }`}
                  >
                    {/* Circle representing the body */}
                    <div
                      style={{
                        width: `${pixelSize}px`,
                        height: `${pixelSize}px`,
                        backgroundColor: planet.color,
                        boxShadow: isTarget
                          ? `0 0 25px ${planet.color}88, inset 0 0 15px rgba(255,255,255,0.4)`
                          : `0 0 10px ${planet.color}44`,
                      }}
                      className="rounded-full transition-all duration-300 relative group-hover:scale-105"
                    />

                    {/* Label */}
                    <div className="text-center">
                      <div
                        className={`text-xs font-semibold whitespace-nowrap ${
                          isTarget ? 'text-cyan-300 font-bold' : 'text-slate-300'
                        }`}
                      >
                        {planet.indonesianName}
                      </div>
                      <div className="text-[10px] font-mono text-slate-500">
                        {planet.diameterKm.toLocaleString('id-ID')} km
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Detailed Comparison Spotlight with Earth */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left: Earth Reference Card */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div className="text-xs font-mono text-cyan-400 font-semibold uppercase">
              Standar Acuan Kehidupan
            </div>
            <h4 className="text-xl font-bold text-white flex items-center gap-2">
              <span className="w-3 h-3 rounded-full bg-blue-500 inline-block" />
              Planet Bumi
            </h4>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Diameter:</span>
                <span className="font-mono font-semibold">12.742 km</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Gravitasi:</span>
                <span className="font-mono font-semibold">9,81 m/s² (1 G)</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Tipe:</span>
                <span>Planet Terestrial Berbatu</span>
              </div>
            </div>
          </div>

          {/* Middle: Math Comparison Insight Card */}
          <div className="p-5 rounded-2xl bg-cyan-950/40 border border-cyan-500/30 flex flex-col justify-center text-center space-y-3">
            <div className="text-xs font-semibold uppercase text-cyan-300 tracking-wider">
              Rasio Terhadap Bumi
            </div>
            <div className="text-4xl font-extrabold text-white font-mono">
              {ratioVsEarth} ×
            </div>
            <p className="text-xs sm:text-sm text-cyan-100">
              Diameter <strong>{selectedPlanet.indonesianName}</strong> adalah{' '}
              <strong className="text-cyan-300">{ratioVsEarth} kali lipat</strong> diameter Bumi.
            </p>
            {selectedPlanet.id !== 'earth' && (
              <div className="p-3 bg-slate-900/70 rounded-xl text-xs text-slate-300 border border-slate-800">
                {Number(ratioVsEarth) > 1 ? (
                  <span>
                    Secara volume geometris, sekitar{' '}
                    <strong className="text-amber-400">{volumeRatio.toLocaleString('id-ID')} planet Bumi</strong>{' '}
                    dapat dimuat ke dalam bola {selectedPlanet.indonesianName}!
                  </span>
                ) : (
                  <span>
                    Bumi memiliki volume sekitar{' '}
                    <strong className="text-amber-400">{(1 / Number(ratioVsEarth)).toFixed(1)} kali lebih besar</strong>{' '}
                    daripada {selectedPlanet.indonesianName}.
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Right: Selected Planet Target Card */}
          <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div className="text-xs font-mono text-amber-400 font-semibold uppercase">
              Planet yang Dipilih
            </div>
            <h4 className="text-xl font-bold text-white flex items-center justify-between">
              <span className="flex items-center gap-2">
                <span
                  className="w-3 h-3 rounded-full inline-block"
                  style={{ backgroundColor: selectedPlanet.color }}
                />
                {selectedPlanet.indonesianName}
              </span>
              <button
                onClick={() => {
                  onSelectPlanet(selectedPlanet);
                  onClose();
                }}
                className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-medium"
              >
                <span>Lihat 3D</span>
                <ArrowRight className="w-3 h-3" />
              </button>
            </h4>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Diameter:</span>
                <span className="font-mono font-semibold">{selectedPlanet.diameterFormatted}</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Gravitasi:</span>
                <span className="font-mono font-semibold">{selectedPlanet.gravityMps2} m/s²</span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Tipe:</span>
                <span>{selectedPlanet.type}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Fact banner */}
        <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800 text-xs text-slate-400 flex items-start gap-3">
          <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong>Catatan Astronomi:</strong> Planet di Tata Surya terbagi menjadi dua kelompok besar oleh Sabuk Asteroid: kelompok <em>Planet Kebumian/Terestrial</em> (Merkurius, Venus, Bumi, Mars) yang berukuran relatif kecil dengan permukaan batu padat, dan kelompok <em>Planet Raksasa</em> (Jupiter, Saturnus, Uranus, Neptunus) yang berukuran luar biasa masif dengan atmosfer gas tebal atau mantel es bertekanan super.
          </p>
        </div>
      </div>
    </div>
  );
};
