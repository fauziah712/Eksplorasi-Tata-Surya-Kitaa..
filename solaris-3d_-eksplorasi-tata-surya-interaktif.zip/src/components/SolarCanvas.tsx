import React, { useEffect, useRef, useState, useCallback } from 'react';
import * as THREE from 'three';
import { PLANETS_DATA } from '../data/planetsData';
import { PlanetData, SimulationSettings } from '../types/solar';
import {
  getSunTexture,
  getMercuryTexture,
  getVenusTexture,
  getEarthTexture,
  getEarthCloudsTexture,
  getMarsTexture,
  getJupiterTexture,
  getSaturnTexture,
  getSaturnRingsTexture,
  getUranusTexture,
  getNeptuneTexture,
  getMoonTexture,
} from '../utils/proceduralTextures';
import { cosmicAudio } from '../utils/audio';

interface SolarCanvasProps {
  selectedPlanet: PlanetData | null;
  onSelectPlanet: (planet: PlanetData | null) => void;
  settings: SimulationSettings;
}

interface PlanetMeshBundle {
  data: PlanetData;
  mesh: THREE.Mesh;
  pivot: THREE.Object3D;
  cloudsMesh?: THREE.Mesh;
  moonGroup?: THREE.Group;
  currentOrbitAngle: number;
}

export const SolarCanvas: React.FC<SolarCanvasProps> = ({
  selectedPlanet,
  onSelectPlanet,
  settings,
}) => {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  // Projected 2D screen positions for labels
  const [labels, setLabels] = useState<
    { id: string; name: string; x: number; y: number; visible: boolean }[]
  >([]);

  // Internal 3D scene state refs to avoid re-instantiation
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const planetBundlesRef = useRef<Map<string, PlanetMeshBundle>>(new Map());
  const orbitLinesGroupRef = useRef<THREE.Group | null>(null);
  const asteroidBeltRef = useRef<THREE.Points | null>(null);
  const sunMeshRef = useRef<THREE.Mesh | null>(null);
  const sunGlowRef = useRef<THREE.Mesh | null>(null);

  // Camera animation and orbit controller state
  const cameraTargetRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 0, 0));
  const cameraDesiredPosRef = useRef<THREE.Vector3>(new THREE.Vector3(0, 65, 115));
  const isTransitioningCameraRef = useRef<boolean>(false);
  const transitionProgressRef = useRef<number>(1);
  const cameraStartPosRef = useRef<THREE.Vector3>(new THREE.Vector3());
  const cameraStartTargetRef = useRef<THREE.Vector3>(new THREE.Vector3());

  // Manual Orbit controls state
  const isDraggingRef = useRef<boolean>(false);
  const isPanningRef = useRef<boolean>(false);
  const prevMousePosRef = useRef<{ x: number; y: number }>({ x: 0, y: 0 });
  const sphericalRef = useRef<THREE.Spherical>(new THREE.Spherical(125, Math.PI / 3, 0));
  const pinchStartDistRef = useRef<number>(0);

  // Hover detection raycaster
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseScreenRef = useRef<THREE.Vector2>(new THREE.Vector2(-999, -999));
  const hoveredPlanetIdRef = useRef<string | null>(null);

  // Handle Planet Selection & Camera Transition
  const triggerCameraTransition = useCallback(
    (targetPlanet: PlanetData | null) => {
      if (!cameraRef.current) return;

      isTransitioningCameraRef.current = true;
      transitionProgressRef.current = 0;
      cameraStartPosRef.current.copy(cameraRef.current.position);
      cameraStartTargetRef.current.copy(cameraTargetRef.current);

      if (targetPlanet) {
        cosmuteWarpSound();
        const bundle = planetBundlesRef.current.get(targetPlanet.id);
        if (bundle) {
          const worldPos = new THREE.Vector3();
          bundle.mesh.getWorldPosition(worldPos);

          const distanceOffset = targetPlanet.id === 'sun' ? 14 : targetPlanet.radiusScale * 4.2;
          cameraDesiredPosRef.current.set(
            worldPos.x + distanceOffset * 0.8,
            worldPos.y + distanceOffset * 0.5,
            worldPos.z + distanceOffset * 1.2
          );
        }
      } else {
        // Overview of whole solar system
        cosmuteWarpSound();
        cameraDesiredPosRef.current.set(0, 75, 125);
      }
    },
    []
  );

  const cosmuteWarpSound = () => {
    if (settings.soundEnabled) {
      cosmicAudio.playWarp();
    }
  };

  useEffect(() => {
    triggerCameraTransition(selectedPlanet);
  }, [selectedPlanet, triggerCameraTransition]);

  // Update Orbit Lines visibility based on settings
  useEffect(() => {
    if (orbitLinesGroupRef.current) {
      orbitLinesGroupRef.current.visible = settings.showOrbits;
    }
  }, [settings.showOrbits]);

  // Update Asteroid Belt visibility
  useEffect(() => {
    if (asteroidBeltRef.current) {
      asteroidBeltRef.current.visible = settings.showAsteroidBelt;
    }
  }, [settings.showAsteroidBelt]);

  // Scene Initialization
  useEffect(() => {
    const container = containerRef.current;
    const canvas = canvasRef.current;
    if (!container || !canvas) return;

    // 1. Scene
    const scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x030712, 0.0006);
    sceneRef.current = scene;

    // 2. Camera
    const aspect = container.clientWidth / container.clientHeight;
    const camera = new THREE.PerspectiveCamera(45, aspect, 0.1, 3000);
    camera.position.set(0, 75, 125);
    camera.lookAt(0, 0, 0);
    cameraRef.current = camera;

    // 3. Renderer
    const renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      powerPreference: 'high-performance',
      alpha: false,
    });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.1;
    rendererRef.current = renderer;

    // 4. Starfield & Deep Space Environment
    const starCount = 3800;
    const starGeo = new THREE.BufferGeometry();
    const starPositions = new Float32Array(starCount * 3);
    const starColors = new Float32Array(starCount * 3);

    const spectralPalettes = [
      new THREE.Color(0xffffff), // Pure white
      new THREE.Color(0xdbeafe), // Cool blue
      new THREE.Color(0xfef08a), // Warm yellow
      new THREE.Color(0xfecaca), // Faint reddish
      new THREE.Color(0x93c5fd), // Azure
    ];

    for (let i = 0; i < starCount; i++) {
      const radius = 600 + Math.random() * 1200;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(Math.random() * 2 - 1);

      starPositions[i * 3] = radius * Math.sin(phi) * Math.cos(theta);
      starPositions[i * 3 + 1] = radius * Math.sin(phi) * Math.sin(theta);
      starPositions[i * 3 + 2] = radius * Math.cos(phi);

      const color = spectralPalettes[Math.floor(Math.random() * spectralPalettes.length)];
      starColors[i * 3] = color.r;
      starColors[i * 3 + 1] = color.g;
      starColors[i * 3 + 2] = color.b;
    }

    starGeo.setAttribute('position', new THREE.BufferAttribute(starPositions, 3));
    starGeo.setAttribute('color', new THREE.BufferAttribute(starColors, 3));

    const starMat = new THREE.PointsMaterial({
      size: 1.8,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
    });
    const starField = new THREE.Points(starGeo, starMat);
    scene.add(starField);

    // 5. Lighting
    // Central Sun light
    const sunLight = new THREE.PointLight(0xfff7e6, 3.2, 800, 0.45);
    sunLight.position.set(0, 0, 0);
    scene.add(sunLight);

    // Soft ambient light to keep planetary dark sides discernible
    const ambientLight = new THREE.AmbientLight(0x1e293b, 0.4);
    scene.add(ambientLight);

    // 6. Build Orbits Group
    const orbitLinesGroup = new THREE.Group();
    orbitLinesGroupRef.current = orbitLinesGroup;
    scene.add(orbitLinesGroup);

    // 7. Asteroid Belt (Between Mars and Jupiter)
    const asteroidCount = 1400;
    const asteroidGeo = new THREE.BufferGeometry();
    const asteroidPos = new Float32Array(asteroidCount * 3);
    const asteroidCol = new Float32Array(asteroidCount * 3);

    for (let a = 0; a < asteroidCount; a++) {
      const r = 30 + Math.random() * 5.2; // Between Mars (27) and Jupiter (37)
      const angle = Math.random() * Math.PI * 2;
      const heightOffset = (Math.random() - 0.5) * 1.8;

      asteroidPos[a * 3] = Math.cos(angle) * r;
      asteroidPos[a * 3 + 1] = heightOffset;
      asteroidPos[a * 3 + 2] = Math.sin(angle) * r;

      const c = 0.5 + Math.random() * 0.3;
      asteroidCol[a * 3] = c;
      asteroidCol[a * 3 + 1] = c * 0.95;
      asteroidCol[a * 3 + 2] = c * 0.9;
    }

    asteroidGeo.setAttribute('position', new THREE.BufferAttribute(asteroidPos, 3));
    asteroidGeo.setAttribute('color', new THREE.BufferAttribute(asteroidCol, 3));

    const asteroidMat = new THREE.PointsMaterial({
      size: 0.9,
      vertexColors: true,
      transparent: true,
      opacity: 0.75,
    });
    const asteroidBelt = new THREE.Points(asteroidGeo, asteroidMat);
    asteroidBeltRef.current = asteroidBelt;
    scene.add(asteroidBelt);

    // 8. Construct Planets & Sun
    const bundles = new Map<string, PlanetMeshBundle>();

    PLANETS_DATA.forEach((planet) => {
      if (planet.id === 'sun') {
        // Sun setup
        const sunGeo = new THREE.SphereGeometry(planet.radiusScale, 48, 48);
        const sunTex = getSunTexture();
        const sunMat = new THREE.MeshBasicMaterial({
          map: sunTex,
        });
        const sunMesh = new THREE.Mesh(sunGeo, sunMat);
        sunMesh.userData = { id: 'sun', data: planet };
        scene.add(sunMesh);
        sunMeshRef.current = sunMesh;

        // Outer atmospheric solar corona glow
        const glowGeo = new THREE.SphereGeometry(planet.radiusScale * 1.22, 32, 32);
        const glowMat = new THREE.MeshBasicMaterial({
          color: 0xffaa33,
          transparent: true,
          opacity: 0.22,
          side: THREE.BackSide,
          blending: THREE.AdditiveBlending,
        });
        const glowMesh = new THREE.Mesh(glowGeo, glowMat);
        scene.add(glowMesh);
        sunGlowRef.current = glowMesh;

        bundles.set('sun', {
          data: planet,
          mesh: sunMesh,
          pivot: scene,
          currentOrbitAngle: 0,
        });
        return;
      }

      // Orbit Line
      const orbitCurve = new THREE.EllipseCurve(
        0,
        0,
        planet.orbitDistance,
        planet.orbitDistance,
        0,
        2 * Math.PI,
        false,
        0
      );
      const orbitPoints = orbitCurve.getPoints(96);
      const orbitGeo = new THREE.BufferGeometry().setFromPoints(
        orbitPoints.map((p) => new THREE.Vector3(p.x, 0, p.y))
      );
      const orbitMat = new THREE.LineBasicMaterial({
        color: 0x38bdf8,
        transparent: true,
        opacity: 0.22,
      });
      const orbitLine = new THREE.LineLoop(orbitGeo, orbitMat);
      orbitLinesGroup.add(orbitLine);

      // Planet Orbit Pivot
      const pivot = new THREE.Group();
      scene.add(pivot);

      // Planet Mesh
      const sphereGeo = new THREE.SphereGeometry(planet.radiusScale, 40, 40);
      let texture: THREE.CanvasTexture;
      switch (planet.textureType) {
        case 'mercury':
          texture = getMercuryTexture();
          break;
        case 'venus':
          texture = getVenusTexture();
          break;
        case 'earth':
          texture = getEarthTexture();
          break;
        case 'mars':
          texture = getMarsTexture();
          break;
        case 'jupiter':
          texture = getJupiterTexture();
          break;
        case 'saturn':
          texture = getSaturnTexture();
          break;
        case 'uranus':
          texture = getUranusTexture();
          break;
        case 'neptune':
          texture = getNeptuneTexture();
          break;
        default:
          texture = getEarthTexture();
      }

      const mat = new THREE.MeshStandardMaterial({
        map: texture,
        roughness: planet.type.includes('Gas') || planet.type.includes('Es') ? 0.7 : 0.85,
        metalness: 0.05,
      });

      const mesh = new THREE.Mesh(sphereGeo, mat);
      // Axial tilt
      mesh.rotation.z = THREE.MathUtils.degToRad(planet.axialTiltDeg);
      mesh.position.set(planet.orbitDistance, 0, 0);
      mesh.userData = { id: planet.id, data: planet };
      pivot.add(mesh);

      let cloudsMesh: THREE.Mesh | undefined;
      let moonGroup: THREE.Group | undefined;

      // Special feature: Earth Clouds Layer & Moon
      if (planet.id === 'earth') {
        const cloudGeo = new THREE.SphereGeometry(planet.radiusScale * 1.022, 40, 40);
        const cloudMat = new THREE.MeshStandardMaterial({
          map: getEarthCloudsTexture(),
          transparent: true,
          opacity: 0.45,
          blending: THREE.NormalBlending,
        });
        cloudsMesh = new THREE.Mesh(cloudGeo, cloudMat);
        mesh.add(cloudsMesh);

        // Moon (Luna)
        moonGroup = new THREE.Group();
        mesh.add(moonGroup);

        const moonGeo = new THREE.SphereGeometry(planet.radiusScale * 0.27, 24, 24);
        const moonMat = new THREE.MeshStandardMaterial({
          map: getMoonTexture(),
          roughness: 0.9,
        });
        const moonMesh = new THREE.Mesh(moonGeo, moonMat);
        moonMesh.position.set(planet.radiusScale * 2.8, 0, 0);
        moonGroup.add(moonMesh);
      }

      // Special feature: Saturn Rings (and Uranus subtle rings)
      if (planet.hasRings && planet.ringInnerRadius && planet.ringOuterRadius) {
        const ringGeo = new THREE.RingGeometry(
          planet.ringInnerRadius,
          planet.ringOuterRadius,
          64
        );

        // Adjust UVs for radial ring mapping
        const pos = ringGeo.attributes.position;
        const uv = ringGeo.attributes.uv;
        for (let i = 0; i < pos.count; i++) {
          const x = pos.getX(i);
          const y = pos.getY(i);
          const dist = Math.sqrt(x * x + y * y);
          const normalized =
            (dist - planet.ringInnerRadius) / (planet.ringOuterRadius - planet.ringInnerRadius);
          uv.setXY(i, normalized, 0.5);
        }

        const ringMat = new THREE.MeshStandardMaterial({
          map: planet.id === 'saturn' ? getSaturnRingsTexture() : undefined,
          color: planet.id === 'uranus' ? 0x93c5fd : 0xffffff,
          side: THREE.DoubleSide,
          transparent: true,
          opacity: planet.id === 'saturn' ? 0.92 : 0.35,
          roughness: 0.5,
        });

        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.rotation.x = Math.PI / 2; // Flat on equator plane
        mesh.add(ringMesh);
      }

      // Initial distributed orbit angles so planets are realistically scattered
      const initialAngle = (planet.orderFromSun * 0.75) % (Math.PI * 2);
      pivot.rotation.y = initialAngle;

      bundles.set(planet.id, {
        data: planet,
        mesh,
        pivot,
        cloudsMesh,
        moonGroup,
        currentOrbitAngle: initialAngle,
      });
    });

    planetBundlesRef.current = bundles;

    // 9. Resize Listener
    const handleResize = () => {
      if (!container || !renderer || !camera) return;
      const w = container.clientWidth;
      const h = container.clientHeight;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    window.addEventListener('resize', handleResize);

    // 10. Animation Loop
    let animFrameId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      animFrameId = requestAnimationFrame(animate);
      const delta = clock.getDelta();

      // Sun pulsing glow
      if (sunMeshRef.current) {
        sunMeshRef.current.rotation.y += 0.001;
      }
      if (sunGlowRef.current) {
        const pulse = 1 + Math.sin(clock.getElapsedTime() * 1.5) * 0.03;
        sunGlowRef.current.scale.set(pulse, pulse, pulse);
      }

      // Asteroid belt gentle drift
      if (asteroidBeltRef.current) {
        asteroidBeltRef.current.rotation.y += 0.0003 * settings.speedMultiplier;
      }

      // Planetary revolution and axial rotation
      bundles.forEach((bundle) => {
        if (bundle.data.id === 'sun') return;

        // Axial spin on planet's own axis
        bundle.mesh.rotation.y += bundle.data.rotationSpeed * (settings.isPlaying ? settings.speedMultiplier : 0);

        // Earth clouds spin slightly faster than planet crust
        if (bundle.cloudsMesh && settings.isPlaying) {
          bundle.cloudsMesh.rotation.y += 0.002 * settings.speedMultiplier;
        }

        // Moon orbit around Earth
        if (bundle.moonGroup && settings.isPlaying) {
          bundle.moonGroup.rotation.y += 0.02 * settings.speedMultiplier;
        }

        // Orbital revolution around Sun
        if (settings.isPlaying) {
          bundle.currentOrbitAngle += bundle.data.orbitSpeed * 0.12 * settings.speedMultiplier * delta;
          bundle.pivot.rotation.y = bundle.currentOrbitAngle;
        }
      });

      // Camera Smooth Interpolation & Tracking
      if (isTransitioningCameraRef.current) {
        transitionProgressRef.current += delta * 1.8;
        const t = Math.min(1, transitionProgressRef.current);
        const ease = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t; // Smooth cubic-like ease

        camera.position.lerpVectors(cameraStartPosRef.current, cameraDesiredPosRef.current, ease);
        cameraTargetRef.current.lerpVectors(
          cameraStartTargetRef.current,
          selectedPlanet && bundles.has(selectedPlanet.id)
            ? getSelectedPlanetWorldPos(selectedPlanet.id)
            : new THREE.Vector3(0, 0, 0),
          ease
        );
        camera.lookAt(cameraTargetRef.current);

        if (t >= 1) {
          isTransitioningCameraRef.current = false;
        }
      } else if (selectedPlanet && bundles.has(selectedPlanet.id)) {
        // In focus mode: smoothly track selected planet as it moves in orbit
        const targetWorldPos = getSelectedPlanetWorldPos(selectedPlanet.id);
        const targetDelta = targetWorldPos.clone().sub(cameraTargetRef.current);
        cameraTargetRef.current.copy(targetWorldPos);
        camera.position.add(targetDelta); // Maintain relative camera distance
        camera.lookAt(cameraTargetRef.current);
      }

      // Update 2D Label screen positions
      if (settings.showLabels) {
        updateScreenLabels(camera, container);
      } else if (labels.length > 0) {
        setLabels([]);
      }

      renderer.render(scene, camera);
    };

    const getSelectedPlanetWorldPos = (id: string): THREE.Vector3 => {
      const b = bundles.get(id);
      if (!b) return new THREE.Vector3(0, 0, 0);
      const pos = new THREE.Vector3();
      b.mesh.getWorldPosition(pos);
      return pos;
    };

    const updateScreenLabels = (cam: THREE.PerspectiveCamera, cont: HTMLElement) => {
      const halfW = cont.clientWidth / 2;
      const halfH = cont.clientHeight / 2;
      const newLabels: { id: string; name: string; x: number; y: number; visible: boolean }[] = [];

      bundles.forEach((b) => {
        const wp = new THREE.Vector3();
        b.mesh.getWorldPosition(wp);
        // Project to screen space
        wp.project(cam);

        // Check if point is in front of camera
        const isVisible = wp.z < 1;
        const sx = wp.x * halfW + halfW;
        const sy = -wp.y * halfH + halfH;

        newLabels.push({
          id: b.data.id,
          name: b.data.indonesianName,
          x: sx,
          y: sy,
          visible: isVisible,
        });
      });
      setLabels(newLabels);
    };

    animate();

    return () => {
      cancelAnimationFrame(animFrameId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      starGeo.dispose();
      asteroidGeo.dispose();
    };
  }, [settings.isPlaying, settings.speedMultiplier, settings.showLabels]);

  // Pointer / Touch Handlers for 360° Free Control & Click Selection
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.setPointerCapture(e.pointerId);
    isDraggingRef.current = true;
    isPanningRef.current = e.button === 2; // Right click = pan
    prevMousePosRef.current = { x: e.clientX, y: e.clientY };
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    const camera = cameraRef.current;
    if (!canvas || !camera) return;

    // Track mouse coords for raycasting hover
    const rect = canvas.getBoundingClientRect();
    mouseScreenRef.current.x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    mouseScreenRef.current.y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    // Check hover
    if (sceneRef.current) {
      raycasterRef.current.setFromCamera(mouseScreenRef.current, camera);
      const meshes: THREE.Mesh[] = [];
      planetBundlesRef.current.forEach((b) => meshes.push(b.mesh));
      const intersects = raycasterRef.current.intersectObjects(meshes, false);

      if (intersects.length > 0) {
        canvas.style.cursor = 'pointer';
        const hitPlanetId = intersects[0].object.userData.id;
        hoveredPlanetIdRef.current = hitPlanetId;
      } else {
        canvas.style.cursor = isDraggingRef.current ? 'grabbing' : 'default';
        hoveredPlanetIdRef.current = null;
      }
    }

    if (!isDraggingRef.current) return;

    const dx = e.clientX - prevMousePosRef.current.x;
    const dy = e.clientY - prevMousePosRef.current.y;
    prevMousePosRef.current = { x: e.clientX, y: e.clientY };

    if (isPanningRef.current) {
      // Pan camera target
      const panSpeed = 0.05;
      const right = new THREE.Vector3(1, 0, 0).applyQuaternion(camera.quaternion);
      const up = new THREE.Vector3(0, 1, 0).applyQuaternion(camera.quaternion);
      camera.position.addScaledVector(right, -dx * panSpeed);
      camera.position.addScaledVector(up, dy * panSpeed);
      cameraTargetRef.current.addScaledVector(right, -dx * panSpeed);
      cameraTargetRef.current.addScaledVector(up, dy * panSpeed);
    } else {
      // 360° Orbit Rotation around target
      const rotSpeed = 0.006;
      const offset = camera.position.clone().sub(cameraTargetRef.current);
      sphericalRef.current.setFromVector3(offset);

      sphericalRef.current.theta -= dx * rotSpeed;
      sphericalRef.current.phi -= dy * rotSpeed;
      // Clamp vertical phi so camera doesn't flip upside down
      sphericalRef.current.phi = Math.max(0.08, Math.min(Math.PI - 0.08, sphericalRef.current.phi));

      offset.setFromSpherical(sphericalRef.current);
      camera.position.copy(cameraTargetRef.current).add(offset);
      camera.lookAt(cameraTargetRef.current);
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.currentTarget.releasePointerCapture(e.pointerId);
    isDraggingRef.current = false;
    isPanningRef.current = false;
    if (canvasRef.current) {
      canvasRef.current.style.cursor = 'default';
    }
  };

  // Click on 3D planet
  const handleClick = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    const camera = cameraRef.current;
    const scene = sceneRef.current;
    if (!canvas || !camera || !scene) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 2 - 1;
    const y = -((e.clientY - rect.top) / rect.height) * 2 + 1;

    raycasterRef.current.setFromCamera(new THREE.Vector2(x, y), camera);
    const meshes: THREE.Mesh[] = [];
    planetBundlesRef.current.forEach((b) => meshes.push(b.mesh));
    const intersects = raycasterRef.current.intersectObjects(meshes, false);

    if (intersects.length > 0) {
      const clickedData = intersects[0].object.userData.data as PlanetData;
      if (clickedData) {
        if (settings.soundEnabled) {
          cosmicAudio.playPlanetSelect(clickedData.orderFromSun);
        }
        onSelectPlanet(clickedData);
      }
    }
  };

  // Zoom In / Out with Scroll Wheel
  const handleWheel = (e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const camera = cameraRef.current;
    if (!camera) return;

    const zoomSpeed = 0.05;
    const offset = camera.position.clone().sub(cameraTargetRef.current);
    const dist = offset.length();
    const newDist = Math.max(5, Math.min(350, dist * (1 + e.deltaY * 0.0015)));

    offset.setLength(newDist);
    camera.position.copy(cameraTargetRef.current).add(offset);
  };

  // Mobile pinch-to-zoom touch support
  const handleTouchMove = (e: React.TouchEvent<HTMLCanvasElement>) => {
    if (e.touches.length === 2 && cameraRef.current) {
      const t1 = e.touches[0];
      const t2 = e.touches[1];
      const dist = Math.hypot(t1.clientX - t2.clientX, t1.clientY - t2.clientY);

      if (pinchStartDistRef.current > 0) {
        const factor = pinchStartDistRef.current / dist;
        const camera = cameraRef.current;
        const offset = camera.position.clone().sub(cameraTargetRef.current);
        const curDist = offset.length();
        const newDist = Math.max(5, Math.min(350, curDist * (factor > 1 ? 1.03 : 0.97)));
        offset.setLength(newDist);
        camera.position.copy(cameraTargetRef.current).add(offset);
      }
      pinchStartDistRef.current = dist;
    }
  };

  const handleTouchEnd = () => {
    pinchStartDistRef.current = 0;
  };

  return (
    <div ref={containerRef} className="relative w-full h-full overflow-hidden select-none bg-slate-950">
      <canvas
        ref={canvasRef}
        className="w-full h-full block touch-none"
        onPointerDown={handlePointerDown}
        onPointerMove={handlePointerMove}
        onPointerUp={handlePointerUp}
        onClick={handleClick}
        onWheel={handleWheel}
        onTouchMove={handleTouchMove}
        onTouchEnd={handleTouchEnd}
        onContextMenu={(e) => e.preventDefault()}
      />

      {/* Dynamic 2D Planet Name Labels Projected in Space */}
      {settings.showLabels &&
        labels.map((lbl) => {
          if (!lbl.visible) return null;
          const isSelected = selectedPlanet?.id === lbl.id;
          return (
            <button
              key={lbl.id}
              onClick={(e) => {
                e.stopPropagation();
                const p = PLANETS_DATA.find((item) => item.id === lbl.id);
                if (p) {
                  if (settings.soundEnabled) {
                    cosmicAudio.playPlanetSelect(p.orderFromSun);
                  }
                  onSelectPlanet(p);
                }
              }}
              style={{
                transform: `translate(${lbl.x}px, ${lbl.y}px) translate(-50%, -100%)`,
              }}
              className={`absolute top-0 left-0 pointer-events-auto text-xs px-2 py-0.5 rounded transition-all duration-150 backdrop-blur-sm ${
                isSelected
                  ? 'bg-cyan-500/90 text-slate-950 font-bold shadow-lg shadow-cyan-500/40 ring-2 ring-cyan-300 scale-110'
                  : 'bg-slate-900/70 hover:bg-slate-800 text-slate-200 border border-slate-700/50 hover:border-cyan-400/50'
              }`}
            >
              {lbl.name}
            </button>
          );
        })}
    </div>
  );
};
