import React from 'react';
import { SimulationSettings } from '../types/solar';
import {
  Play,
  Pause,
  FastForward,
  Eye,
  EyeOff,
  CircleDot,
  Volume2,
  VolumeX,
  Compass,
  HelpCircle,
  Maximize2,
} from 'lucide-react';
import { cosmicAudio } from '../utils/audio';

interface ControlsHUDProps {
  settings: SimulationSettings;
  onUpdateSettings: (updater: (prev: SimulationSettings) => SimulationSettings) => void;
  onResetCamera: () => void;
  onOpenHelp: () => void;
}

const SPEED_PRESETS = [0.5, 1, 5, 15, 30];

export const ControlsHUD: React.FC<ControlsHUDProps> = ({
  settings,
  onUpdateSettings,
  onResetCamera,
  onOpenHelp,
}) => {
  const togglePlay = () => {
    if (settings.soundEnabled) cosmicAudio.playClick(800);
    onUpdateSettings((prev) => ({ ...prev, isPlaying: !prev.isPlaying }));
  };

  const setSpeed = (spd: number) => {
    if (settings.soundEnabled) cosmicAudio.playClick(900);
    onUpdateSettings((prev) => ({ ...prev, speedMultiplier: spd }));
  };

  const toggleOrbits = () => {
    if (settings.soundEnabled) cosmicAudio.playClick(750);
    onUpdateSettings((prev) => ({ ...prev, showOrbits: !prev.showOrbits }));
  };

  const toggleLabels = () => {
    if (settings.soundEnabled) cosmicAudio.playClick(750);
    onUpdateSettings((prev) => ({ ...prev, showLabels: !prev.showLabels }));
  };

  const toggleSound = () => {
    const nextVal = !settings.soundEnabled;
    cosmicAudio.setEnabled(nextVal);
    if (nextVal) cosmicAudio.playClick(880);
    onUpdateSettings((prev) => ({ ...prev, soundEnabled: nextVal }));
  };

  return (
    <div
      aria-label="Panel Kontrol Simulasi"
      className="fixed top-18 left-3 sm:left-4 z-20 flex flex-col gap-2 max-w-[260px]"
    >
      {/* Simulation Playback & Speed Card */}
      <div className="p-2 sm:p-2.5 bg-slate-950/80 backdrop-blur-md border border-cyan-500/20 rounded-2xl shadow-xl shadow-black/50 text-slate-200">
        <div className="flex items-center justify-between mb-2">
          <div className="text-xs font-semibold uppercase tracking-wider text-cyan-400">
            Simulasi Orbit
          </div>
          <button
            onClick={togglePlay}
            className={`p-1.5 rounded-lg flex items-center gap-1 text-xs font-bold transition-colors ${
              settings.isPlaying
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/40'
            }`}
            title={settings.isPlaying ? 'Jeda Simulasi' : 'Lanjutkan Simulasi'}
          >
            {settings.isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{settings.isPlaying ? 'Jeda' : 'Jalan'}</span>
          </button>
        </div>

        {/* Speed presets */}
        <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
          <FastForward className="w-3.5 h-3.5 text-slate-400 ml-1 shrink-0" />
          <div className="flex items-center justify-between flex-1 gap-0.5">
            {SPEED_PRESETS.map((spd) => (
              <button
                key={spd}
                onClick={() => setSpeed(spd)}
                className={`flex-1 py-1 text-xs font-mono rounded-lg transition-colors text-center ${
                  settings.speedMultiplier === spd
                    ? 'bg-cyan-500 text-slate-950 font-bold shadow-sm'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {spd}x
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Layer Toggles & Utility HUD */}
      <div className="p-2 sm:p-2.5 bg-slate-950/80 backdrop-blur-md border border-cyan-500/20 rounded-2xl shadow-xl shadow-black/50 text-slate-200 space-y-1.5">
        <button
          onClick={toggleOrbits}
          className={`w-full flex items-center justify-between px-2.5 py-1.5 text-xs rounded-xl transition-colors ${
            settings.showOrbits
              ? 'bg-slate-900/80 text-cyan-300 border border-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <span className="flex items-center gap-2">
            <CircleDot className="w-3.5 h-3.5" />
            <span>Garis Orbit</span>
          </span>
          <span className="text-xs font-mono">{settings.showOrbits ? 'ON' : 'OFF'}</span>
        </button>

        <button
          onClick={toggleLabels}
          className={`w-full flex items-center justify-between px-2.5 py-1.5 text-xs rounded-xl transition-colors ${
            settings.showLabels
              ? 'bg-slate-900/80 text-cyan-300 border border-cyan-500/30'
              : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
          }`}
        >
          <span className="flex items-center gap-2">
            {settings.showLabels ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
            <span>Label Nama</span>
          </span>
          <span className="text-xs font-mono">{settings.showLabels ? 'ON' : 'OFF'}</span>
        </button>

        <div className="grid grid-cols-3 gap-1 pt-1 border-t border-slate-800">
          {/* Sound Toggle */}
          <button
            onClick={toggleSound}
            className={`p-1.5 rounded-xl flex items-center justify-center transition-colors ${
              settings.soundEnabled
                ? 'bg-slate-900 text-cyan-400 border border-slate-800'
                : 'bg-slate-900 text-slate-500 border border-slate-800'
            }`}
            title={settings.soundEnabled ? 'Matikan Suara SFX' : 'Nyalakan Suara SFX'}
          >
            {settings.soundEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>

          {/* Reset Camera */}
          <button
            onClick={onResetCamera}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 flex items-center justify-center transition-colors"
            title="Reset Sudut Kamera (Overview)"
          >
            <Compass className="w-4 h-4 text-cyan-400" />
          </button>

          {/* Guide Help */}
          <button
            onClick={onOpenHelp}
            className="p-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 flex items-center justify-center transition-colors"
            title="Panduan Navigasi & Kontrol"
          >
            <HelpCircle className="w-4 h-4 text-amber-400" />
          </button>
        </div>
      </div>
    </div>
  );
};
