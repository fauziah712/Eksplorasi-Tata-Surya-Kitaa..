import * as THREE from 'three';

// Procedural Canvas Texture Generator for Photorealistic Planets
// Eliminates network dependencies and CORS issues, ensuring 100% reliable rendering

const textureCache = new Map<string, THREE.CanvasTexture>();

function createNoiseContext(width: number, height: number): [HTMLCanvasElement, CanvasRenderingContext2D] {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d')!;
  return [canvas, ctx];
}

// Simple deterministic pseudo-random noise generator
function pseudoNoise(x: number, y: number, seed: number = 42): number {
  const n = Math.sin(x * 12.9898 + y * 78.233 + seed) * 43758.5453;
  return n - Math.floor(n);
}

// Multi-octave perlin-like noise approximation on canvas
function drawPerlinNoise(
  ctx: CanvasRenderingContext2D,
  width: number,
  height: number,
  scale: number,
  octaves: number,
  colorA: string,
  colorB: string
) {
  const imgData = ctx.createImageData(width, height);
  const data = imgData.data;

  // Pre-parse colors
  const dummyA = document.createElement('div');
  dummyA.style.color = colorA;
  document.body.appendChild(dummyA);
  const rgbA = getComputedStyle(dummyA).color.match(/\d+/g)!.map(Number);
  dummyA.style.color = colorB;
  const rgbB = getComputedStyle(dummyA).color.match(/\d+/g)!.map(Number);
  document.body.removeChild(dummyA);

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      let val = 0;
      let freq = scale;
      let amp = 1;
      let maxAmp = 0;

      for (let o = 0; o < octaves; o++) {
        const nx = (x / width) * freq;
        const ny = (y / height) * freq;
        val += pseudoNoise(Math.floor(nx), Math.floor(ny), o * 17) * amp;
        maxAmp += amp;
        amp *= 0.5;
        freq *= 2;
      }
      const norm = val / maxAmp;
      const idx = (y * width + x) * 4;

      data[idx] = rgbA[0] * (1 - norm) + rgbB[0] * norm;
      data[idx + 1] = rgbA[1] * (1 - norm) + rgbB[1] * norm;
      data[idx + 2] = rgbA[2] * (1 - norm) + rgbB[2] * norm;
      data[idx + 3] = 255;
    }
  }
  ctx.putImageData(imgData, 0, 0);
}

// 1. Sun Texture (Solar plasma, granulation, solar flares)
export function getSunTexture(): THREE.CanvasTexture {
  if (textureCache.has('sun')) return textureCache.get('sun')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  // Base fiery background
  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, '#ff4500');
  grad.addColorStop(0.5, '#ffa500');
  grad.addColorStop(1, '#ff3300');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Solar convection granulation & turbulence
  for (let i = 0; i < 600; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const r = 5 + Math.random() * 45;
    const alpha = 0.15 + Math.random() * 0.35;

    const radial = ctx.createRadialGradient(x, y, 0, x, y, r);
    radial.addColorStop(0, `rgba(255, 245, 180, ${alpha})`);
    radial.addColorStop(0.4, `rgba(255, 170, 20, ${alpha * 0.7})`);
    radial.addColorStop(1, 'rgba(255, 60, 0, 0)');

    ctx.fillStyle = radial;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Cooler sunspots
  for (let i = 0; i < 18; i++) {
    const sx = Math.random() * width;
    const sy = height * 0.25 + Math.random() * height * 0.5;
    const sr = 3 + Math.random() * 8;

    const spot = ctx.createRadialGradient(sx, sy, 0, sx, sy, sr);
    spot.addColorStop(0, 'rgba(120, 25, 0, 0.85)');
    spot.addColorStop(0.6, 'rgba(180, 50, 0, 0.5)');
    spot.addColorStop(1, 'rgba(255, 140, 0, 0)');

    ctx.fillStyle = spot;
    ctx.beginPath();
    ctx.arc(sx, sy, sr, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.ClampToEdgeWrapping;
  textureCache.set('sun', texture);
  return texture;
}

// 2. Mercury Texture (Cratered rocky gray-tan terrain)
export function getMercuryTexture(): THREE.CanvasTexture {
  if (textureCache.has('mercury')) return textureCache.get('mercury')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  ctx.fillStyle = '#6e6761';
  ctx.fillRect(0, 0, width, height);

  // Basalt plains and subtle tonal shifts
  for (let i = 0; i < 200; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const r = 20 + Math.random() * 90;
    const isDark = Math.random() > 0.45;
    const col = isDark ? 'rgba(60, 55, 50, 0.25)' : 'rgba(150, 140, 130, 0.2)';

    ctx.fillStyle = col;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Impact craters with white ejecta rays
  for (let c = 0; c < 280; c++) {
    const cx = Math.random() * width;
    const cy = Math.random() * height;
    const cr = 2 + Math.random() * 16;

    // Rim highlight
    ctx.strokeStyle = 'rgba(220, 215, 205, 0.4)';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.arc(cx, cy, cr, 0, Math.PI * 2);
    ctx.stroke();

    // Floor shadow
    ctx.fillStyle = 'rgba(35, 30, 25, 0.45)';
    ctx.beginPath();
    ctx.arc(cx + cr * 0.2, cy + cr * 0.2, cr * 0.75, 0, Math.PI * 2);
    ctx.fill();

    // Central peak for large craters
    if (cr > 8) {
      ctx.fillStyle = 'rgba(230, 225, 215, 0.5)';
      ctx.beginPath();
      ctx.arc(cx, cy, 1.5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('mercury', texture);
  return texture;
}

// 3. Venus Texture (Dense swirling sulfuric cloud deck)
export function getVenusTexture(): THREE.CanvasTexture {
  if (textureCache.has('venus')) return textureCache.get('venus')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  // Gradient base
  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, '#e5be85');
  grad.addColorStop(0.3, '#edd8a6');
  grad.addColorStop(0.5, '#e0b878');
  grad.addColorStop(0.7, '#d6a860');
  grad.addColorStop(1, '#c89648');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Swirling chevron cloud patterns
  ctx.lineWidth = 14;
  for (let y = 10; y < height; y += 18) {
    const waveAmp = 15 + Math.sin(y * 0.05) * 12;
    ctx.strokeStyle = y % 36 === 0 ? 'rgba(255, 245, 210, 0.25)' : 'rgba(180, 130, 60, 0.18)';
    ctx.beginPath();
    ctx.moveTo(0, y);
    for (let x = 0; x <= width; x += 40) {
      const cy = y + Math.sin((x / width) * Math.PI * 4) * waveAmp;
      ctx.lineTo(x, cy);
    }
    ctx.stroke();
  }

  // Soft atmospheric vortexes
  for (let i = 0; i < 40; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const r = 30 + Math.random() * 80;

    const vortex = ctx.createRadialGradient(x, y, 0, x, y, r);
    vortex.addColorStop(0, 'rgba(255, 250, 225, 0.18)');
    vortex.addColorStop(1, 'rgba(200, 150, 80, 0)');
    ctx.fillStyle = vortex;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('venus', texture);
  return texture;
}

// 4. Earth Texture (Vibrant oceans, continents, polar caps)
export function getEarthTexture(): THREE.CanvasTexture {
  if (textureCache.has('earth')) return textureCache.get('earth')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  // 1. Deep Ocean base with realistic continental shelf glow
  const oceanGrad = ctx.createLinearGradient(0, 0, 0, height);
  oceanGrad.addColorStop(0, '#0a2342');
  oceanGrad.addColorStop(0.5, '#0c356a');
  oceanGrad.addColorStop(1, '#0a2342');
  ctx.fillStyle = oceanGrad;
  ctx.fillRect(0, 0, width, height);

  // Shallow coastal waters / turquoise reefs
  function drawContinent(cx: number, cy: number, rx: number, ry: number, angle: number = 0) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(angle);

    // Shallow water aura
    ctx.fillStyle = 'rgba(20, 140, 160, 0.35)';
    ctx.beginPath();
    ctx.ellipse(0, 0, rx * 1.15, ry * 1.15, 0, 0, Math.PI * 2);
    ctx.fill();

    // Landmass base (greenish-brown)
    ctx.fillStyle = '#2d5a27';
    ctx.beginPath();
    ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill();

    // Mountain ranges / arid interior
    ctx.fillStyle = '#8b7355';
    ctx.beginPath();
    ctx.ellipse(rx * 0.1, -ry * 0.1, rx * 0.5, ry * 0.6, 0, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
  }

  // Major continental approximations for iconic Earth appearance:
  // Eurasia & Africa
  drawContinent(width * 0.52, height * 0.34, 110, 60, -0.1); // Eurasia
  drawContinent(width * 0.50, height * 0.60, 65, 80, 0.15); // Africa
  drawContinent(width * 0.62, height * 0.44, 45, 35, 0.2); // India/Middle East
  drawContinent(width * 0.78, height * 0.70, 50, 40, -0.1); // Australia
  drawContinent(width * 0.72, height * 0.56, 40, 25, 0.3); // SE Asia islands

  // Americas
  drawContinent(width * 0.24, height * 0.32, 90, 65, -0.2); // North America
  drawContinent(width * 0.30, height * 0.66, 50, 85, 0.2); // South America
  drawContinent(width * 0.26, height * 0.48, 20, 12, 0.4); // Central America

  // Polar Ice Caps
  // North Pole
  const northIce = ctx.createLinearGradient(0, 0, 0, height * 0.14);
  northIce.addColorStop(0, '#ffffff');
  northIce.addColorStop(0.7, '#e0f2fe');
  northIce.addColorStop(1, 'rgba(255, 255, 255, 0)');
  ctx.fillStyle = northIce;
  ctx.fillRect(0, 0, width, height * 0.14);

  // Antarctica (South Pole)
  const southIce = ctx.createLinearGradient(0, height * 0.86, 0, height);
  southIce.addColorStop(0, 'rgba(255, 255, 255, 0)');
  southIce.addColorStop(0.3, '#e0f2fe');
  southIce.addColorStop(1, '#ffffff');
  ctx.fillStyle = southIce;
  ctx.fillRect(0, height * 0.86, width, height * 0.14);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('earth', texture);
  return texture;
}

// 4b. Earth Clouds Texture (Translucent swirling cirrus and storm systems)
export function getEarthCloudsTexture(): THREE.CanvasTexture {
  if (textureCache.has('earth-clouds')) return textureCache.get('earth-clouds')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  ctx.clearRect(0, 0, width, height);

  // Cloud bands and vortexes
  for (let i = 0; i < 90; i++) {
    const x = Math.random() * width;
    const y = height * 0.15 + Math.random() * height * 0.7;
    const rx = 30 + Math.random() * 120;
    const ry = 10 + Math.random() * 35;
    const rot = (Math.random() - 0.5) * 0.6;

    ctx.save();
    ctx.translate(x, y);
    ctx.rotate(rot);

    const grad = ctx.createRadialGradient(0, 0, 0, 0, 0, rx);
    grad.addColorStop(0, 'rgba(255, 255, 255, 0.75)');
    grad.addColorStop(0.5, 'rgba(240, 248, 255, 0.4)');
    grad.addColorStop(1, 'rgba(255, 255, 255, 0)');

    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.ellipse(0, 0, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  }

  // Cyclonic spirals
  for (let c = 0; c < 4; c++) {
    const cx = (c + 0.5) * (width / 4) + (Math.random() - 0.5) * 60;
    const cy = height * 0.35 + (c % 2 === 0 ? 80 : -60);
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.65)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    for (let a = 0; a < Math.PI * 4; a += 0.2) {
      const r = a * 6;
      const x = cx + Math.cos(a) * r;
      const y = cy + Math.sin(a) * r;
      if (a === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('earth-clouds', texture);
  return texture;
}

// 5. Mars Texture (Iron-oxide red, Olympus Mons, Valles Marineris canyon, polar white caps)
export function getMarsTexture(): THREE.CanvasTexture {
  if (textureCache.has('mars')) return textureCache.get('mars')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  // Martian rusty red base
  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, '#a53e1d');
  grad.addColorStop(0.5, '#c1440e');
  grad.addColorStop(1, '#8b2e0b');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Darker basaltic volcanic terrains (Syrtis Major & Acidalia Planitia)
  for (let i = 0; i < 70; i++) {
    const x = Math.random() * width;
    const y = height * 0.25 + Math.random() * height * 0.5;
    const rx = 30 + Math.random() * 110;
    const ry = 20 + Math.random() * 50;

    const darkGrad = ctx.createRadialGradient(x, y, 0, x, y, rx);
    darkGrad.addColorStop(0, 'rgba(70, 25, 10, 0.45)');
    darkGrad.addColorStop(0.7, 'rgba(100, 35, 15, 0.25)');
    darkGrad.addColorStop(1, 'rgba(193, 68, 14, 0)');

    ctx.fillStyle = darkGrad;
    ctx.beginPath();
    ctx.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Valles Marineris canyon scar
  ctx.strokeStyle = 'rgba(50, 15, 5, 0.6)';
  ctx.lineWidth = 4;
  ctx.beginPath();
  ctx.moveTo(width * 0.35, height * 0.54);
  ctx.bezierCurveTo(width * 0.45, height * 0.52, width * 0.55, height * 0.57, width * 0.65, height * 0.55);
  ctx.stroke();

  // Polar ice caps (dry ice / water ice)
  // North Pole
  const nIce = ctx.createRadialGradient(width * 0.5, 0, 0, width * 0.5, 0, height * 0.12);
  nIce.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
  nIce.addColorStop(0.7, 'rgba(240, 220, 220, 0.6)');
  nIce.addColorStop(1, 'rgba(165, 62, 29, 0)');
  ctx.fillStyle = nIce;
  ctx.fillRect(0, 0, width, height * 0.12);

  // South Pole
  const sIce = ctx.createRadialGradient(width * 0.5, height, 0, width * 0.5, height, height * 0.1);
  sIce.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
  sIce.addColorStop(0.7, 'rgba(240, 220, 220, 0.6)');
  sIce.addColorStop(1, 'rgba(139, 46, 11, 0)');
  ctx.fillStyle = sIce;
  ctx.fillRect(0, height * 0.9, width, height * 0.1);

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('mars', texture);
  return texture;
}

// 6. Jupiter Texture (Atmospheric bands, turbulent storms, Great Red Spot)
export function getJupiterTexture(): THREE.CanvasTexture {
  if (textureCache.has('jupiter')) return textureCache.get('jupiter')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  // Characteristic Jovian atmospheric stripes (Belts and Zones)
  const colors = [
    '#5c3d28', // North Polar Region
    '#8c6747', // North North Temperate Belt
    '#d6b896', // North Temperate Zone
    '#9e6b47', // North Temperate Belt
    '#e8d3ba', // North Tropical Zone
    '#7a3818', // North Equatorial Belt (dark reddish brown)
    '#f4ece1', // Equatorial Zone (bright cream)
    '#803c1b', // South Equatorial Belt (dark brown-red)
    '#ecd7c0', // South Tropical Zone
    '#99684b', // South Temperate Belt
    '#d4bca4', // South Temperate Zone
    '#684d3b', // South Polar Region
  ];

  const bandH = height / colors.length;
  for (let i = 0; i < colors.length; i++) {
    const y = i * bandH;
    ctx.fillStyle = colors[i];
    ctx.fillRect(0, y, width, bandH + 2);

    // Zonal shear ripples
    ctx.lineWidth = 3;
    ctx.strokeStyle = i % 2 === 0 ? 'rgba(255, 255, 255, 0.22)' : 'rgba(0, 0, 0, 0.18)';
    ctx.beginPath();
    ctx.moveTo(0, y + bandH / 2);
    for (let x = 0; x <= width; x += 25) {
      const offset = Math.sin((x / width) * Math.PI * 12 + i) * 6;
      ctx.lineTo(x, y + bandH / 2 + offset);
    }
    ctx.stroke();
  }

  // The Great Red Spot (Iconic massive storm oval in the southern hemisphere)
  const grsX = width * 0.62;
  const grsY = height * 0.64;
  const grsRx = 55;
  const grsRy = 32;

  // Outer turbulence wake
  ctx.strokeStyle = 'rgba(235, 120, 80, 0.5)';
  ctx.lineWidth = 6;
  ctx.beginPath();
  ctx.ellipse(grsX + 30, grsY, grsRx * 1.5, grsRy * 1.2, 0, 0, Math.PI * 2);
  ctx.stroke();

  // Core Red Spot
  const spotGrad = ctx.createRadialGradient(grsX, grsY, 0, grsX, grsY, grsRx);
  spotGrad.addColorStop(0, '#b83b1d');
  spotGrad.addColorStop(0.6, '#d95a2b');
  spotGrad.addColorStop(0.9, '#e88f62');
  spotGrad.addColorStop(1, 'rgba(232, 143, 98, 0)');

  ctx.fillStyle = spotGrad;
  ctx.beginPath();
  ctx.ellipse(grsX, grsY, grsRx, grsRy, -0.08, 0, Math.PI * 2);
  ctx.fill();

  // White oval storms in temperate belts
  for (let w = 0; w < 12; w++) {
    const wx = Math.random() * width;
    const wy = height * 0.72 + (Math.random() - 0.5) * 35;
    ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
    ctx.beginPath();
    ctx.ellipse(wx, wy, 8, 5, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('jupiter', texture);
  return texture;
}

// 7. Saturn Texture (Warm golden-butterscotch bands)
export function getSaturnTexture(): THREE.CanvasTexture {
  if (textureCache.has('saturn')) return textureCache.get('saturn')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  const saturnBands = [
    '#91846b', // Polar cap
    '#b4a382',
    '#d9c89e',
    '#ebd9ae', // Bright equatorial zone
    '#f5e6c2',
    '#e2ce9f',
    '#c7b282',
    '#aa986b',
    '#8a7b54',
  ];

  const bandH = height / saturnBands.length;
  for (let i = 0; i < saturnBands.length; i++) {
    const y = i * bandH;
    ctx.fillStyle = saturnBands[i];
    ctx.fillRect(0, y, width, bandH + 1);

    // Subtle atmospheric flow
    ctx.fillStyle = i % 2 === 0 ? 'rgba(255, 255, 255, 0.08)' : 'rgba(0, 0, 0, 0.05)';
    ctx.fillRect(0, y + bandH * 0.3, width, bandH * 0.4);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('saturn', texture);
  return texture;
}

// 7b. Saturn Rings Texture (Radial striped rings with Cassini division & transparency)
export function getSaturnRingsTexture(): THREE.CanvasTexture {
  if (textureCache.has('saturn-rings')) return textureCache.get('saturn-rings')!;

  const size = 1024;
  const [canvas, ctx] = createNoiseContext(size, 64);

  // Radial slice from inner ring (left = 0) to outer ring (right = size)
  ctx.clearRect(0, 0, size, 64);

  // C Ring (innermost, dim & translucent)
  const cGrad = ctx.createLinearGradient(0, 0, size * 0.25, 0);
  cGrad.addColorStop(0, 'rgba(160, 140, 110, 0)');
  cGrad.addColorStop(0.3, 'rgba(170, 150, 120, 0.35)');
  cGrad.addColorStop(1, 'rgba(180, 160, 130, 0.5)');
  ctx.fillStyle = cGrad;
  ctx.fillRect(0, 0, size * 0.25, 64);

  // B Ring (brightest, dense)
  const bGrad = ctx.createLinearGradient(size * 0.25, 0, size * 0.65, 0);
  bGrad.addColorStop(0, 'rgba(225, 210, 180, 0.85)');
  bGrad.addColorStop(0.5, 'rgba(245, 235, 205, 0.95)');
  bGrad.addColorStop(1, 'rgba(215, 195, 165, 0.85)');
  ctx.fillStyle = bGrad;
  ctx.fillRect(size * 0.25, 0, size * 0.4, 64);

  // Cassini Division (dark gap)
  ctx.fillStyle = 'rgba(10, 10, 15, 0.05)';
  ctx.fillRect(size * 0.65, 0, size * 0.06, 64);

  // A Ring (outer bright ring with Encke gap)
  const aGrad = ctx.createLinearGradient(size * 0.71, 0, size, 0);
  aGrad.addColorStop(0, 'rgba(205, 190, 160, 0.75)');
  aGrad.addColorStop(0.7, 'rgba(195, 180, 150, 0.7)');
  aGrad.addColorStop(1, 'rgba(150, 135, 110, 0)');
  ctx.fillStyle = aGrad;
  ctx.fillRect(size * 0.71, 0, size * 0.29, 64);

  // Fine ringlets lines across the structure
  for (let x = 0; x < size; x += 4) {
    if (Math.random() > 0.4) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.15)';
      ctx.fillRect(x, 0, 1.5, 64);
    }
  }

  const texture = new THREE.CanvasTexture(canvas);
  textureCache.set('saturn-rings', texture);
  return texture;
}

// 8. Uranus Texture (Pale cyan-aquamarine ice giant)
export function getUranusTexture(): THREE.CanvasTexture {
  if (textureCache.has('uranus')) return textureCache.get('uranus')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, '#7ce4e8');
  grad.addColorStop(0.45, '#a4f0f2');
  grad.addColorStop(0.55, '#a9f5f7');
  grad.addColorStop(1, '#6cd5d9');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // Subtle pastel methane clouds
  ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
  for (let y = 100; y < 400; y += 45) {
    ctx.fillRect(0, y, width, 18);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('uranus', texture);
  return texture;
}

// 9. Neptune Texture (Deep azure blue with storm vortexes and white cirrus streaks)
export function getNeptuneTexture(): THREE.CanvasTexture {
  if (textureCache.has('neptune')) return textureCache.get('neptune')!;

  const width = 1024;
  const height = 512;
  const [canvas, ctx] = createNoiseContext(width, height);

  const grad = ctx.createLinearGradient(0, 0, 0, height);
  grad.addColorStop(0, '#1a3375');
  grad.addColorStop(0.3, '#274b9f');
  grad.addColorStop(0.5, '#3b67cc');
  grad.addColorStop(0.7, '#254ba3');
  grad.addColorStop(1, '#152960');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, width, height);

  // The Great Dark Spot (Neptunian anti-cyclonic storm)
  const spotX = width * 0.45;
  const spotY = height * 0.42;
  const spotGrad = ctx.createRadialGradient(spotX, spotY, 0, spotX, spotY, 40);
  spotGrad.addColorStop(0, 'rgba(12, 25, 60, 0.85)');
  spotGrad.addColorStop(0.7, 'rgba(20, 45, 105, 0.5)');
  spotGrad.addColorStop(1, 'rgba(59, 103, 204, 0)');

  ctx.fillStyle = spotGrad;
  ctx.beginPath();
  ctx.ellipse(spotX, spotY, 42, 24, -0.15, 0, Math.PI * 2);
  ctx.fill();

  // Bright white high-altitude methane cirrus clouds ("Scooter")
  ctx.strokeStyle = 'rgba(255, 255, 255, 0.7)';
  ctx.lineWidth = 2.5;
  for (let s = 0; s < 18; s++) {
    const sx = Math.random() * width;
    const sy = height * 0.3 + Math.random() * height * 0.4;
    const slen = 40 + Math.random() * 80;

    ctx.beginPath();
    ctx.moveTo(sx, sy);
    ctx.lineTo(sx + slen, sy + (Math.random() - 0.5) * 6);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('neptune', texture);
  return texture;
}

// 10. Moon Texture (Lunar craters and maria)
export function getMoonTexture(): THREE.CanvasTexture {
  if (textureCache.has('moon')) return textureCache.get('moon')!;

  const width = 512;
  const height = 256;
  const [canvas, ctx] = createNoiseContext(width, height);

  ctx.fillStyle = '#9ca3af';
  ctx.fillRect(0, 0, width, height);

  // Dark lunar maria (basalt plains)
  ctx.fillStyle = 'rgba(55, 65, 81, 0.45)';
  for (let i = 0; i < 20; i++) {
    const x = Math.random() * width;
    const y = Math.random() * height;
    const r = 15 + Math.random() * 45;
    ctx.beginPath();
    ctx.arc(x, y, r, 0, Math.PI * 2);
    ctx.fill();
  }

  // Craters
  ctx.strokeStyle = 'rgba(243, 244, 246, 0.5)';
  ctx.lineWidth = 1;
  for (let c = 0; c < 120; c++) {
    const cx = Math.random() * width;
    const cy = Math.random() * height;
    const cr = 2 + Math.random() * 8;
    ctx.beginPath();
    ctx.arc(cx, cy, cr, 0, Math.PI * 2);
    ctx.stroke();
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.wrapS = THREE.RepeatWrapping;
  textureCache.set('moon', texture);
  return texture;
}
