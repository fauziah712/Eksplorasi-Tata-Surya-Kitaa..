/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { SolarCanvas } from './components/SolarCanvas';
import { PlanetInfoModal } from './components/PlanetInfoModal';
import { PlanetQuickNav } from './components/PlanetQuickNav';
import { ControlsHUD } from './components/ControlsHUD';
import { ComparisonView } from './components/ComparisonView';
import { QuizModal } from './components/QuizModal';
import { HelpGuideModal } from './components/HelpGuideModal';
import { PlanetData, SimulationSettings } from './types/solar';
import {
  Trophy,
  Scale,
  Orbit,
  HelpCircle,
  Compass,
  Sparkles,
} from 'lucide-react';
import { cosmicAudio } from './utils/audio';

export default function App() {
  const [selectedPlanet, setSelectedPlanet] = useState<PlanetData | null>(null);
  const [showComparison, setShowComparison] = useState<boolean>(false);
  const [showQuiz, setShowQuiz] = useState<boolean>(false);
  const [showHelp, setShowHelp] = useState<boolean>(false);

  const [settings, setSettings] = useState<SimulationSettings>({
    isPlaying: true,
    speedMultiplier: 1,
    showOrbits: true,
    showLabels: true,
    showAsteroidBelt: true,
    soundEnabled: true,
  });

  const handleSelectPlanet = (planet: PlanetData | null) => {
    setSelectedPlanet(planet);
  };

  const handleResetCamera = () => {
    if (settings.soundEnabled) cosmicAudio.playClick(700);
    setSelectedPlanet(null);
  };

  const openComparison = () => {
    if (settings.soundEnabled) cosmicAudio.playClick(850);
    setShowComparison(true);
    setShowQuiz(false);
  };

  const openQuiz = () => {
    if (settings.soundEnabled) cosmicAudio.playClick(850);
    setShowQuiz(true);
    setShowComparison(false);
  };

  const openHelp = () => {
    if (settings.soundEnabled) cosmicAudio.playClick(750);
    setShowHelp(true);
  };

  return (
    <div className="relative w-screen h-screen overflow-hidden bg-slate-950 font-sans text-slate-100 flex flex-col">
      {/* Top Bar Navigation (Strict 3-zone contract) */}
      <header className="h-14 sm:h-16 px-4 sm:px-6 flex items-center justify-between border-b border-cyan-500/20 bg-slate-950/85 backdrop-blur-md z-30 shrink-0">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={handleResetCamera}
          className="text-lg sm:text-xl font-extrabold tracking-tight text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-sky-300 to-amber-300 flex items-center gap-2 hover:opacity-90 transition-opacity"
        >
          <Orbit className="w-5 h-5 sm:w-6 sm:h-6 text-cyan-400 animate-spin-slow" />
          <span>Solaris 3D</span>
        </button>

        {/* Zone 2: 3-4 clean navigation tabs */}
        <nav className="flex items-center gap-1 sm:gap-2 text-xs sm:text-sm font-medium">
          <button
            onClick={() => {
              if (settings.soundEnabled) cosmicAudio.playClick(800);
              setShowComparison(false);
              setShowQuiz(false);
            }}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
              !showComparison && !showQuiz
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Orbit className="w-4 h-4 hidden xs:inline" />
            <span>Simulasi 3D</span>
          </button>

          <button
            onClick={openComparison}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
              showComparison
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Scale className="w-4 h-4 hidden xs:inline" />
            <span>Bandingkan Ukuran</span>
          </button>

          <button
            onClick={openQuiz}
            className={`px-3 py-1.5 rounded-xl transition-all whitespace-nowrap flex items-center gap-1.5 ${
              showQuiz
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 shadow-sm font-semibold'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/60'
            }`}
          >
            <Trophy className="w-4 h-4 text-amber-400 hidden xs:inline" />
            <span className="flex items-center gap-1">
              <span>Kuis Evaluasi</span>
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse hidden sm:inline" />
            </span>
          </button>
        </nav>

        {/* Zone 3: Primary Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={openHelp}
            className="p-2 sm:px-3 sm:py-1.5 text-xs font-medium text-slate-300 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl transition-colors flex items-center gap-1.5"
            title="Bantuan Kontrol Navigasi"
          >
            <HelpCircle className="w-4 h-4 text-amber-400" />
            <span className="hidden sm:inline">Panduan</span>
          </button>

          <button
            onClick={handleResetCamera}
            className="hidden md:flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold text-cyan-300 hover:text-slate-950 bg-cyan-950/60 hover:bg-cyan-400 border border-cyan-500/40 rounded-xl transition-colors whitespace-nowrap shadow-sm"
            title="Kembali ke Tampilan Penuh Tata Surya"
          >
            <Compass className="w-3.5 h-3.5" />
            <span>Tata Surya</span>
          </button>
        </div>
      </header>

      {/* Main 3D Stage Viewport */}
      <main className="relative flex-1 w-full h-full overflow-hidden">
        <SolarCanvas
          selectedPlanet={selectedPlanet}
          onSelectPlanet={handleSelectPlanet}
          settings={settings}
        />

        {/* Floating Simulation HUD Controls */}
        <ControlsHUD
          settings={settings}
          onUpdateSettings={setSettings}
          onResetCamera={handleResetCamera}
          onOpenHelp={openHelp}
        />

        {/* Bottom Docked Quick Navigation */}
        <PlanetQuickNav
          selectedPlanet={selectedPlanet}
          onSelectPlanet={handleSelectPlanet}
          soundEnabled={settings.soundEnabled}
        />

        {/* Detailed Planet Information Side Drawer */}
        {selectedPlanet && (
          <PlanetInfoModal
            planet={selectedPlanet}
            onClose={() => setSelectedPlanet(null)}
            onSelectPlanet={handleSelectPlanet}
            onResetView={handleResetCamera}
            soundEnabled={settings.soundEnabled}
          />
        )}

        {/* Comparison Laboratory Modal */}
        {showComparison && (
          <ComparisonView
            onClose={() => setShowComparison(false)}
            onSelectPlanet={(planet) => {
              setSelectedPlanet(planet);
              setShowComparison(false);
            }}
            soundEnabled={settings.soundEnabled}
          />
        )}

        {/* Quiz & Evaluation Interactive Game Modal */}
        {showQuiz && (
          <QuizModal
            onClose={() => setShowQuiz(false)}
            onExplorePlanetIn3D={(planet) => {
              setSelectedPlanet(planet);
              setShowQuiz(false);
            }}
            soundEnabled={settings.soundEnabled}
          />
        )}

        {/* Help & Control Guide Modal */}
        {showHelp && (
          <HelpGuideModal
            onClose={() => setShowHelp(false)}
            soundEnabled={settings.soundEnabled}
          />
        )}
      </main>
    </div>
  );
}
