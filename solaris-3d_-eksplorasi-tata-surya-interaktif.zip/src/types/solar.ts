export interface PlanetData {
  id: string;
  name: string;
  indonesianName: string;
  orderFromSun: number; // 0 for Sun, 1 for Mercury, etc.
  type: 'Bintang' | 'Planet Kebumian (Terestrial)' | 'Raksasa Gas' | 'Raksasa Es' | 'Satelit Alami';
  tagline: string;
  overview: string;
  
  // Physical & Astronomical Characteristics
  diameterKm: number;
  diameterFormatted: string;
  massKg: string;
  distanceFromSunMillionKm: number;
  distanceFormatted: string;
  surfaceTempCelsius: string;
  rotationPeriod: string; // Lama rotasi (hari)
  revolutionPeriod: string; // Lama revolusi (tahun)
  axialTiltDeg: number;
  naturalSatellitesCount: number;
  gravityMps2: number;
  composition: string[];
  
  // Life Potential Analysis
  lifePotential: {
    status: 'Tidak Layak' | 'Sangat Mustahil' | 'Zona Layak Huni (Kehidupan Mikro Sedang Diteliti)' | 'Layak Huni Penuh' | string;
    summary: string;
    atmosphere: string;
    waterPresence: string;
    radiationAndMagnetism: string;
    mainObstacleOrSupport: string;
  };

  // Benefits & Fascinating Facts
  benefitsAndFacts: {
    solarSystemRole: string; // Peran kestabilan tata surya
    magneticFieldFunction: string; // Fungsi medan magnet
    uniqueFacts: string[];
  };

  // Visual & 3D rendering params
  color: string;
  secondaryColor?: string;
  emissiveColor?: string;
  radiusScale: number; // relative display scale in 3D
  orbitDistance: number; // relative distance in 3D
  orbitSpeed: number; // relative revolution speed
  rotationSpeed: number; // relative axial spin speed
  hasRings?: boolean;
  ringInnerRadius?: number;
  ringOuterRadius?: number;
  textureType: 'sun' | 'mercury' | 'venus' | 'earth' | 'mars' | 'jupiter' | 'saturn' | 'uranus' | 'neptune' | 'moon';
}

export interface QuizQuestion {
  id: string;
  type: 'multiple-choice' | 'guess-planet';
  title: string;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  clues?: string[]; // for guess planet mode
  targetPlanetId?: string;
  difficulty: 'Mudah' | 'Sedang' | 'Tantangan';
}

export type ViewMode = 'system' | 'focus' | 'comparison' | 'quiz';

export interface SimulationSettings {
  isPlaying: boolean;
  speedMultiplier: number;
  showOrbits: boolean;
  showLabels: boolean;
  showAsteroidBelt: boolean;
  soundEnabled: boolean;
}
