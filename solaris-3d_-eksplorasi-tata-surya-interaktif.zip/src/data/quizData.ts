import { QuizQuestion } from '../types/solar';

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  // Mode: Tebak Planet (Visual & Clue)
  {
    id: 'guess-1',
    type: 'guess-planet',
    title: 'Tebak Planet Misterius #1',
    question: 'Planet apakah ini? Berwarna merah kecokelatan, memiliki ngarai terdalam Valles Marineris dan gunung berapi tertinggi bernama Olympus Mons.',
    clues: [
      'Memiliki dua satelit alami berukuran kecil bernama Phobos dan Deimos.',
      'Sering dijuluki sebagai Planet Merah karena banyaknya karat besi di permukaannya.',
      'Menjadi target utama penjelajahan rover NASA seperti Curiosity dan Perseverance.'
    ],
    targetPlanetId: 'mars',
    options: ['Merkurius', 'Venus', 'Mars', 'Jupiter'],
    correctIndex: 2,
    explanation: 'Tepat sekali! Mars terkenal dengan warna kemerahan akibat tingginya kandungan besi oksida (karat) di permukaannya. Mars juga memiliki Olympus Mons yang tingginya mencapai hampir 22 km!',
    difficulty: 'Mudah'
  },
  {
    id: 'guess-2',
    type: 'guess-planet',
    title: 'Tebak Planet Misterius #2',
    question: 'Planet apakah ini? Bola gas raksasa dengan corak garis-garis atmosfer memukau dan pusaran badai Bintik Merah Besar (Great Red Spot).',
    clues: [
      'Planet paling masif di Tata Surya kita—lebih dari 2 kali gabungan semua planet lain.',
      'Memiliki gravitasi teramat kuat yang bertindak bagai perisai pelindung Bumi dari tabrakan komet liar.',
      'Memiliki 4 satelit besar yang ditemukan oleh Galileo: Io, Europa, Ganymede, dan Callisto.'
    ],
    targetPlanetId: 'jupiter',
    options: ['Saturnus', 'Jupiter', 'Neptunus', 'Uranus'],
    correctIndex: 1,
    explanation: 'Hebat! Jupiter adalah planet terbesar di Tata Surya. Gravitasinya yang luar biasa bertindak seperti "penyedot debu kosmis", melindungi planet-planet dalam seperti Bumi dari hantaman komet!',
    difficulty: 'Mudah'
  },
  {
    id: 'guess-3',
    type: 'guess-planet',
    title: 'Tebak Planet Misterius #3',
    question: 'Planet apakah ini? Tampak kuning keemasan dengan sistem cincin es spektakuler selebar 282.000 km yang sangat tipis.',
    clues: [
      'Kerapatannya sangat rendah, bahkan lebih ringan daripada air (ia akan mengapung jika ada kolam raksasa).',
      'Memiliki badai berbentuk heksagonal unik di kutub utaranya.',
      'Memiliki lebih dari 140 bulan, dengan Titan sebagai bulan terbesarnya yang beratmosfer tebal.'
    ],
    targetPlanetId: 'saturn',
    options: ['Venus', 'Saturnus', 'Uranus', 'Merkurius'],
    correctIndex: 1,
    explanation: 'Benar sekali! Saturnus adalah permata Tata Surya dengan cincin es yang indah. Menariknya, kerapatan Saturnus rata-rata hanya 0,687 g/cm³, menjadikannya satu-satunya planet yang bisa mengapung di atas air!',
    difficulty: 'Mudah'
  },
  {
    id: 'guess-4',
    type: 'guess-planet',
    title: 'Tebak Planet Misterius #4',
    question: 'Planet apakah ini? Berwarna biru toska dengan kemiringan poros rotasi ekstrem 98 derajat, sehingga tampak menggelinding di jalurnya.',
    clues: [
      'Mengalami malam kutub selama 42 tahun dan siang selama 42 tahun berturut-turut.',
      'Atmosfernya sangat dingin mencapai -224 °C karena minimnya panas internal.',
      'Planet pertama yang ditemukan menggunakan teleskop oleh astronom William Herschel.'
    ],
    targetPlanetId: 'uranus',
    options: ['Bumi', 'Neptunus', 'Uranus', 'Venus'],
    correctIndex: 2,
    explanation: 'Luar biasa! Uranus berputar hampir sepenuhnya rebah di bidang orbitnya (kemiringan 97,77°), kemungkinan besar akibat tabrakan raksasa dengan protoplanet seukuran Bumi pada awal pembentukan tata surya.',
    difficulty: 'Sedang'
  },
  {
    id: 'guess-5',
    type: 'guess-planet',
    title: 'Tebak Planet Misterius #5',
    question: 'Planet apakah ini? Berwarna biru kobalt pekat dengan badai supersonik bertiup melebihi 2.000 km/jam di pinggiran terluar tata surya.',
    clues: [
      'Ditemukan melalui perhitungan prediksi matematika sebelum terlihat lewat teleskop.',
      'Memerlukan waktu hampir 165 tahun Bumi untuk menyelesaikan satu kali orbit mengelilingi Matahari.',
      'Bulannya, Triton, mengorbit mundur (retrograde) dan menyemburkan geiser nitrogen beku.'
    ],
    targetPlanetId: 'neptune',
    options: ['Bumi', 'Uranus', 'Neptunus', 'Merkurius'],
    correctIndex: 2,
    explanation: 'Sempurna! Neptunus adalah planet terjauh yang memiliki kecepatan angin tercepat di Tata Surya kita, mencapai 2.100 km/jam, dan rona birunya berasal dari kandungan gas metana di atmosfernya.',
    difficulty: 'Sedang'
  },

  // Mode: Soal Pilihan Ganda Astronomi
  {
    id: 'mcq-1',
    type: 'multiple-choice',
    title: 'Misteri Suhu Planet',
    question: 'Mengapa planet Venus bersuhu lebih panas (465 °C) daripada Merkurius, padahal Merkurius berada lebih dekat dengan Matahari?',
    options: [
      'Karena Venus memiliki gunung berapi aktif yang mengeluarkan magma di seluruh permukaannya.',
      'Karena atmosfer Venus sangat pekat dengan gas karbon dioksida yang memicu efek rumah kaca tak terkendali.',
      'Karena Venus berputar sangat cepat sehingga gesekan udaranya menghasilkan panas tinggi.',
      'Karena Venus menyerap energi langsung dari inti planet Jupiter.'
    ],
    correctIndex: 1,
    explanation: 'Tepat! Atmosfer Venus 96,5% terdiri dari karbondioksida dengan tekanan 92 kali atmosfer Bumi. Hal ini memerangkap radiasi inframerah panas Matahari secara total (efek rumah kaca ekstrem), membuat suhunya merata 465 °C siang dan malam.',
    difficulty: 'Sedang'
  },
  {
    id: 'mcq-2',
    type: 'multiple-choice',
    title: 'Perisai Tata Surya',
    question: 'Bagaimana peran gravitasi planet Jupiter yang sangat besar dalam membantu melindungi kehidupan di planet Bumi?',
    options: [
      'Jupiter memancarkan medan radiasi cahaya yang menghangatkan iklim kutub Bumi.',
      'Gravitasi Jupiter bertindak sebagai penyedot debu kosmis yang membelokkan komet dan asteroid bahaya dari jalur tabrakan dengan Bumi.',
      'Jupiter menghentikan angin matahari agar tidak membakar lapisan ozon Bumi.',
      'Jupiter memperlambat laju revolusi Bumi agar empat musim tetap berganti.'
    ],
    correctIndex: 1,
    explanation: 'Tepat sekali! Karena massanya 318 kali Bumi, gaya gravitasi Jupiter yang masif menangkap atau melontarkan asteroid dan komet liar ke luar tata surya. Tanpa Jupiter, frekuensi hantaman asteroid besar ke Bumi akan jauh lebih sering.',
    difficulty: 'Sedang'
  },
  {
    id: 'mcq-3',
    type: 'multiple-choice',
    title: 'Hari yang Lebih Panjang dari Tahun',
    question: 'Planet di Tata Surya yang memiliki keunikan berupa periode rotasi (1 hari) yang lebih lama daripada periode revolusinya (1 tahun) adalah...',
    options: [
      'Mars',
      'Merkurius',
      'Venus',
      'Saturnus'
    ],
    correctIndex: 2,
    explanation: 'Benar! Venus membutuhkan 243 hari Bumi untuk berputar sekali pada porosnya (rotasi), namun hanya butuh 225 hari Bumi untuk mengelilingi Matahari (revolusi). Jadi, 1 hari di Venus lebih panjang daripada 1 tahunnya!',
    difficulty: 'Sedang'
  },
  {
    id: 'mcq-4',
    type: 'multiple-choice',
    title: 'Bahan Penyusun Cincin Saturnus',
    question: 'Tahukah kamu dari materi apakah sebagian besar (lebih dari 95%) cincin Saturnus yang megah itu tersusun?',
    options: [
      'Bongkahan emas dan besi cair yang membeku.',
      'Partikel dan bongkahan es air murni bercampur debu batuan kosmis.',
      'Gas helium murni yang terperangkap medan magnetik.',
      'Debu karbon padat sisa letusan gunung api purba.'
    ],
    correctIndex: 1,
    explanation: 'Hebat! Cincin Saturnus terdiri dari miliaran partikel yang ukurannya bervariasi dari butiran pasir hingga sebesar rumah, di mana lebih dari 95% adalah es air murni (H₂O) yang memantulkan sinar matahari dengan sangat cemerlang.',
    difficulty: 'Mudah'
  },
  {
    id: 'mcq-5',
    type: 'multiple-choice',
    title: 'Urutan Planet Kebumian (Terestrial)',
    question: 'Empat planet terdekat dari Matahari disebut sebagai "Planet Kebumian" atau Terestrial karena memiliki permukaan padat berbatu. Urutan yang tepat dari yang terdekat adalah...',
    options: [
      'Merkurius – Bumi – Venus – Mars',
      'Merkurius – Venus – Bumi – Mars',
      'Venus – Merkurius – Mars – Bumi',
      'Mars – Bumi – Venus – Merkurius'
    ],
    correctIndex: 1,
    explanation: 'Tepat sekali! Urutan 4 planet terestrial dari Matahari adalah Merkurius (1), Venus (2), Bumi (3), dan Mars (4). Setelah Mars terdapat Sabuk Asteroid yang membatasi dengan kelompok planet gas luar.',
    difficulty: 'Mudah'
  },
  {
    id: 'mcq-6',
    type: 'multiple-choice',
    title: 'Medan Magnet & Sabuk Pelindung Bumi',
    question: 'Apa fungsi utama medan magnet (magnetosfer) Bumi bagi kelangsungan hidup makhluk hidup di permukaannya?',
    options: [
      'Menghasilkan gravitasi agar manusia tidak melayang ke luar angkasa.',
      'Membelokkan partikel angin matahari bermuatan radiasi tinggi mematikan dan mencegah kikisan atmosfer.',
      'Menjaga air laut agar tidak membeku menjadi es abadi.',
      'Menjaga perputaran rotasi Bumi agar tepat 24 jam sehari.'
    ],
    correctIndex: 1,
    explanation: 'Benar sekali! Magnetosfer yang dibangkitkan oleh perputaran dinamo inti besi cair Bumi membelokkan partikel radiasi angin matahari berbahaya, menyelamatkan atmosfer kita dari terkikis habis seperti yang dialami Mars kuno.',
    difficulty: 'Tantangan'
  }
];
