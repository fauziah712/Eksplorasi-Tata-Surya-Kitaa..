import { PlanetData } from '../types/solar';

export const PLANETS_DATA: PlanetData[] = [
  {
    id: 'sun',
    name: 'Sun',
    indonesianName: 'Matahari',
    orderFromSun: 0,
    type: 'Bintang',
    tagline: 'Jantung Energi & Pusat Gravitasi Tata Surya',
    overview: 'Matahari adalah bintang katai kuning (tipe spektrum G2V) yang menjadi pusat Tata Surya kita. Mengandung 99,86% dari seluruh massa tata surya, gravitasinya mengikat seluruh planet, komet, dan asteroid dalam orbit harmonis.',
    diameterKm: 1392700,
    diameterFormatted: '1.392.700 km (109 × Bumi)',
    massKg: '1,989 × 10³⁰ kg (333.000 × Bumi)',
    distanceFromSunMillionKm: 0,
    distanceFormatted: '0 km (Pusat Tata Surya)',
    surfaceTempCelsius: '5.500 °C (Inti: 15.000.000 °C)',
    rotationPeriod: '25 – 35 hari Bumi (rotasi diferensial)',
    revolutionPeriod: '230 juta tahun (Orbit Galaksi Bima Sakti)',
    axialTiltDeg: 7.25,
    naturalSatellitesCount: 8, // Mengorbitkan 8 planet utama
    gravityMps2: 274.0,
    composition: ['Hidrogen (74,9%)', 'Helium (23,8%)', 'Oksigen (1%)', 'Karbon, Neon, Besi'],
    lifePotential: {
      status: 'Sangat Mustahil',
      summary: 'Matahari adalah reaktor fusi termonuklir raksasa dengan radiasi mematikan dan suhu jutaan derajat.',
      atmosphere: 'Korona dan kromosfer plasma berpijar yang melontarkan badai flare matahari.',
      waterPresence: 'Tidak ada; suhu ekstrem seketika menguapkan dan memecah molekul air menjadi ion hidrogen dan oksigen.',
      radiationAndMagnetism: 'Medan magnet teramat kuat memutar siklus 11 tahunan yang memicu lontaran massa korona (CME).',
      mainObstacleOrSupport: 'Meski tidak dapat dihuni, sinar matahari adalah sumber energi utama penyokong seluruh fotosintesis dan kehidupan di Bumi.'
    },
    benefitsAndFacts: {
      solarSystemRole: 'Jangkar gravitasi absolut yang mencegah seluruh planet terlempar ke kehampaan antarbintang.',
      magneticFieldFunction: 'Membentuk heliosfer—gelembung pelindung raksasa yang menangkis radiasi sinar kosmik berbahaya dari luar galaksi.',
      uniqueFacts: [
        'Di inti Matahari, fusi hidrogen mengubah 600 juta ton hidrogen menjadi helium setiap detiknya.',
        'Cahaya yang kita rasakan di Bumi membutuhkan waktu sekitar 8 menit 20 detik untuk sampai.',
        'Massa Matahari begitu besar hingga mampu memuat sekitar 1,3 juta planet seukuran Bumi di dalamnya.'
      ]
    },
    color: '#ffaa00',
    secondaryColor: '#ff4400',
    emissiveColor: '#ff7700',
    radiusScale: 4.5,
    orbitDistance: 0,
    orbitSpeed: 0,
    rotationSpeed: 0.002,
    textureType: 'sun'
  },
  {
    id: 'mercury',
    name: 'Mercury',
    indonesianName: 'Merkurius',
    orderFromSun: 1,
    type: 'Planet Kebumian (Terestrial)',
    tagline: 'Planet Terkecil & Terdekat dengan Matahari',
    overview: 'Merkurius adalah planet terkecil di Tata Surya dan yang paling dekat dengan Matahari. Permukaannya sangat mirip Bulan Bumi—berbatu, penuh kawah hantaman asteroid kuno, tanpa atmosfer tebal penyimpan panas.',
    diameterKm: 4879,
    diameterFormatted: '4.879 km (0,38 × Bumi)',
    massKg: '3,301 × 10²³ kg (0,055 × Bumi)',
    distanceFromSunMillionKm: 57.9,
    distanceFormatted: '57,9 juta km (0,39 SA)',
    surfaceTempCelsius: '-180 °C (malam) hingga +430 °C (siang)',
    rotationPeriod: '58,6 hari Bumi',
    revolutionPeriod: '88 hari Bumi (Tersingkat)',
    axialTiltDeg: 0.034,
    naturalSatellitesCount: 0,
    gravityMps2: 3.7,
    composition: ['Inti Besi Masif (70%)', 'Mantel Silikat Berbatu (30%)'],
    lifePotential: {
      status: 'Sangat Mustahil',
      summary: 'Perubahan suhu ekstrem antara siang dan malam mencapai rentang 600 °C tanpa adanya atmosfer pelindung.',
      atmosphere: 'Eksosfer sangat tipis yang tersusun dari jejak oksigen, natrium, hidrogen, dan kalium yang tertiup angin matahari.',
      waterPresence: 'Terdapat endapan es abadi terperangkap di dasar kawah kutub yang selalu berada dalam bayangan gelap.',
      radiationAndMagnetism: 'Memiliki medan magnet lemah (hanya 1% kekuatan Bumi) yang tidak cukup membendung radiasi matahari langsung.',
      mainObstacleOrSupport: 'Ketiadaan atmosfer peredam suhu dan radiasi ultraviolet mematikan dari jarak yang sangat dekat.'
    },
    benefitsAndFacts: {
      solarSystemRole: 'Laboratorium alam penting bagi ilmuwan untuk membuktikan Teori Relativitas Umum Albert Einstein melalui presesi perihelionnya.',
      magneticFieldFunction: 'Membelokkan sebagian kecil partikel angin matahari, menghasilkan fenomena dinamika aurora eksosfer mikro.',
      uniqueFacts: [
        'Merkurius bergerak melesat dengan kecepatan revolusi tercepat di tata surya, yakni 47 km/detik.',
        'Satu hari matahari di Merkurius (dari matahari terbit hingga terbit lagi) membutuhkan waktu 176 hari Bumi, dua kali lipat lebih lama dari 1 tahunnya!',
        'Memiliki inti logam besi raksasa yang mencakup hingga 85% dari total jari-jari planetnya.'
      ]
    },
    color: '#9e9a95',
    secondaryColor: '#635e58',
    radiusScale: 0.7,
    orbitDistance: 9,
    orbitSpeed: 0.04,
    rotationSpeed: 0.004,
    textureType: 'mercury'
  },
  {
    id: 'venus',
    name: 'Venus',
    indonesianName: 'Venus',
    orderFromSun: 2,
    type: 'Planet Kebumian (Terestrial)',
    tagline: 'Kembaran Berapi Bumi & Planet Terpanas',
    overview: 'Venus sering disebut sebagai saudara kembar Bumi karena ukuran, massa, dan gravitasinya yang hampir sama. Namun, Venus mengalami efek rumah kaca tak terkendali dengan atmosfer karbondioksida super pekat dan awan asam sulfat.',
    diameterKm: 12104,
    diameterFormatted: '12.104 km (0,95 × Bumi)',
    massKg: '4,867 × 10²⁴ kg (0,815 × Bumi)',
    distanceFromSunMillionKm: 108.2,
    distanceFormatted: '108,2 juta km (0,72 SA)',
    surfaceTempCelsius: '465 °C (Rata-rata Konstan Siang-Malam)',
    rotationPeriod: '243 hari Bumi (Rotasi Terbalik / Retrograde)',
    revolutionPeriod: '224,7 hari Bumi',
    axialTiltDeg: 177.3,
    naturalSatellitesCount: 0,
    gravityMps2: 8.87,
    composition: ['Karbondioksida (96,5%)', 'Nitrogen (3,5%)', 'Awan Asam Sulfat pekat'],
    lifePotential: {
      status: 'Zona Layak Huni (Kehidupan Mikro Sedang Diteliti)',
      summary: 'Permukaannya sangat mematikan seperti neraka cair, tetapi lapisan awan di ketinggian 50 km memiliki suhu dan tekanan mirip Bumi, tempat ditemukannya jejak gas fosfin yang misterius.',
      atmosphere: 'Tekanan atmosfer di permukaan mencapai 92 bar—setara berada di kedalaman 900 meter di bawah laut Bumi!',
      waterPresence: 'Nyaris kering total; air purbanya lenyap terdisosiasi oleh radiasi ultraviolet dan tertiup ke luar angkasa.',
      radiationAndMagnetism: 'Tidak memiliki medan magnet internal dinamik, hanya medan magnet imbasan dari interaksi atmosfer dengan angin matahari.',
      mainObstacleOrSupport: 'Hujan asam sulfat pekat yang menguap sebelum menyentuh tanah dan efek rumah kaca yang mampu melelehkan timbal.'
    },
    benefitsAndFacts: {
      solarSystemRole: 'Membantu astronom memahami bahaya kritis dari efek rumah kaca ekstrem bagi iklim keplanetan jangka panjang.',
      magneticFieldFunction: 'Interaksi atmosfer atas membentuk busur kejutan (bow shock) yang mengalirkan partikel bermuatan ke belakang planet.',
      uniqueFacts: [
        'Venus berputar berlawanan arah jarum jam (retrograde). Di Venus, Matahari terbit dari barat dan terbenam di timur!',
        'Satu hari di Venus (243 hari Bumi) lebih lama daripada satu tahunnya (225 hari Bumi).',
        'Meskipun bukan yang terdekat dengan Matahari, Venus adalah planet terpanas di seluruh Tata Surya karena efek rumah kaca ekstrem.'
      ]
    },
    color: '#e5be85',
    secondaryColor: '#c79247',
    radiusScale: 1.1,
    orbitDistance: 14,
    orbitSpeed: 0.028,
    rotationSpeed: -0.003,
    textureType: 'venus'
  },
  {
    id: 'earth',
    name: 'Earth',
    indonesianName: 'Bumi',
    orderFromSun: 3,
    type: 'Planet Kebumian (Terestrial)',
    tagline: 'Oase Biru Kosmis & Rumah Kehidupan',
    overview: 'Bumi adalah satu-satunya objek astronomi di alam semesta yang terbukti menjadi rumah bagi jutaan spesies kehidupan. Memiliki air cair di permukaan, atmosfer kaya oksigen, dan medan magnet perisai pelindung yang sempurna.',
    diameterKm: 12742,
    diameterFormatted: '12.742 km (Standar 1,00 × Bumi)',
    massKg: '5,972 × 10²⁴ kg (Standar Massa)',
    distanceFromSunMillionKm: 149.6,
    distanceFormatted: '149,6 juta km (1,00 SA)',
    surfaceTempCelsius: '-89 °C hingga +58 °C (Rata-rata: 15 °C)',
    rotationPeriod: '23 jam 56 menit 4 detik (1 Hari)',
    revolutionPeriod: '365,25 hari (1 Tahun)',
    axialTiltDeg: 23.44,
    naturalSatellitesCount: 1, // Bulan (Luna)
    gravityMps2: 9.81,
    composition: ['Nitrogen (78%)', 'Oksigen (21%)', 'Argon (0,9%)', 'Air & Karbondioksida (0,1%)'],
    lifePotential: {
      status: 'Layak Huni Penuh',
      summary: 'Titik emas kehidupan di alam semesta (Goldilocks Zone) dengan keanekaragaman hayati jutaan spesies terestrial dan bahari.',
      atmosphere: 'Komposisi ideal bernapas dengan lapisan ozon (O₃) yang menyaring 98% sinar radiasi UV-B berbahaya.',
      waterPresence: 'Melimpah; mencakup 71% permukaan planet dalam bentuk samudra cair, sungai, gletser, dan uap awan presipitasi.',
      radiationAndMagnetism: 'Inti besi cair dinamo menciptakan sabuk magnetosfer Van Allen kuat pelindung biosfer dari radiasi kosmis.',
      mainObstacleOrSupport: 'Siklus air alami, tektonik lempeng pengatur karbon, dan pasang surut gravitasi yang distabilkan oleh Bulan.'
    },
    benefitsAndFacts: {
      solarSystemRole: 'Titik peradaban cerdas yang mampu mengamati, mempelajari, dan mengeksplorasi kosmos.',
      magneticFieldFunction: 'Membelokkan angin matahari berenergi tinggi ke arah kutub dan menghasilkan tarian aurora borealis serta australis yang indah.',
      uniqueFacts: [
        'Bumi adalah planet terpadat di Tata Surya kita dengan densitas rata-rata 5,51 gram per sentimeter kubik.',
        'Kemiringan sumbu 23,4 derajat menghasilkan pergantian empat musim yang stabil dan dinamis untuk pertumbuhan flora fauna.',
        'Satelit alaminya, Bulan, menstabilkan goyangan poros rotasi Bumi sehingga iklim kita tetap ramah selama miliaran tahun.'
      ]
    },
    color: '#2b82c9',
    secondaryColor: '#2e7d32',
    radiusScale: 1.15,
    orbitDistance: 20,
    orbitSpeed: 0.02,
    rotationSpeed: 0.015,
    textureType: 'earth'
  },
  {
    id: 'mars',
    name: 'Mars',
    indonesianName: 'Mars',
    orderFromSun: 4,
    type: 'Planet Kebumian (Terestrial)',
    tagline: 'Planet Merah & Destinasi Koloni Masa Depan',
    overview: 'Mars adalah planet berbatu berdebu dengan warna kemerahan akibat tingginya konsentrasi besi oksida (karat) di tanahnya. Memiliki gunung berapi tertinggi dan lembah ngarai terpanjang di seluruh Tata Surya.',
    diameterKm: 6779,
    diameterFormatted: '6.779 km (0,53 × Bumi)',
    massKg: '6,417 × 10²³ kg (0,107 × Bumi)',
    distanceFromSunMillionKm: 227.9,
    distanceFormatted: '227,9 juta km (1,52 SA)',
    surfaceTempCelsius: '-125 °C hingga +20 °C (Rata-rata: -65 °C)',
    rotationPeriod: '24 jam 37 menit 22 detik (1 Sol)',
    revolutionPeriod: '687 hari Bumi (1,88 Tahun)',
    axialTiltDeg: 25.19,
    naturalSatellitesCount: 2, // Phobos & Deimos
    gravityMps2: 3.71,
    composition: ['Besi Oksida (Permukaan)', 'Karbondioksida (95,3%)', 'Nitrogen (2,6%)', 'Argon (1,9%)'],
    lifePotential: {
      status: 'Zona Layak Huni (Kehidupan Mikro Sedang Diteliti)',
      summary: 'Terdapat bukti kuat sungai dan danau purba di masa lalu. Rover NASA Perseverance saat ini mencari fosil mikrobia di kawah Jezero.',
      atmosphere: 'Tipis (hanya 1% tekanan atmosfer Bumi), tidak cukup untuk menahan panas dan didominasi karbondioksida.',
      waterPresence: 'Tersimpan dalam jumlah besar sebagai es abadi di tudung kutub serta kantong es bawah tanah (sub-surface ice).',
      radiationAndMagnetism: 'Inti membeku mematikan medan magnet global miliaran tahun lalu, membiarkan radiasi kosmik menghujani permukaan.',
      mainObstacleOrSupport: 'Gravitasi sepertiga Bumi dan radiasi tinggi memerlukan habitat berpelindung khusus untuk kolonisasi manusia masa depan.'
    },
    benefitsAndFacts: {
      solarSystemRole: 'Target utama eksplorasi antarplanet umat manusia untuk membuka gerbang peradaban multi-planet.',
      magneticFieldFunction: 'Hanya memiliki sisa kemagnetan kerak (crustal magnetism) lokal di wilayah belahan selatan.',
      uniqueFacts: [
        'Memiliki Gunung Olympus Mons—gunung berapi setinggi 21,9 km, hampir 3 kali lipat lebih tinggi dari Gunung Everest!',
        'Lembah Valles Marineris membentang lebih dari 4.000 km—bisa membentang melintasi benua Amerika dari ujung ke ujung.',
        'Matahari terbenam di Mars tampak berwarna biru keperakan karena partikel debu halus di atmosfer menyebarkan cahaya biru.'
      ]
    },
    color: '#c1440e',
    secondaryColor: '#8a2f07',
    radiusScale: 0.85,
    orbitDistance: 27,
    orbitSpeed: 0.015,
    rotationSpeed: 0.014,
    textureType: 'mars'
  },
  {
    id: 'jupiter',
    name: 'Jupiter',
    indonesianName: 'Jupiter',
    orderFromSun: 5,
    type: 'Raksasa Gas',
    tagline: 'Raja Planet & Perisai Pelindung Bumi',
    overview: 'Jupiter adalah planet terbesar di Tata Surya—dua kali lebih masif dari gabungan semua planet lainnya. Terbungkus awan pusaran hidrogen dan helium dengan badai raksasa Bintik Merah Besar yang mengamuk selama ratusan tahun.',
    diameterKm: 139820,
    diameterFormatted: '139.820 km (11 × Bumi)',
    massKg: '1,898 × 10²⁷ kg (317,8 × Bumi)',
    distanceFromSunMillionKm: 778.6,
    distanceFormatted: '778,6 juta km (5,20 SA)',
    surfaceTempCelsius: '-110 °C (Lapisan Awan Terluar)',
    rotationPeriod: '9 jam 55 menit (Rotasi Tercepat)',
    revolutionPeriod: '11,86 tahun Bumi',
    axialTiltDeg: 3.13,
    naturalSatellitesCount: 95, // Termasuk satelit Galilea: Io, Europa, Ganymede, Callisto
    gravityMps2: 24.79,
    composition: ['Hidrogen (90%)', 'Helium (10%)', 'Metana, Amonia, Inti Logam Berat Tertekan'],
    lifePotential: {
      status: 'Tidak Layak (Namun Bulannya Europa Sangat Berpotensi)',
      summary: 'Di dalam atmosfer Jupiter, tekanan dan suhu ekstrem akan menghancurkan pesawat luar angkasa dalam hitungan detik. Namun, bulannya Europa memiliki samudra cair bawah tanah dengan potensi kehidupan laut.',
      atmosphere: 'Lapisan awan amonia dan amonium hidrosulfida dengan kecepatan angin badai jet stream melampaui 600 km/jam.',
      waterPresence: 'Terdapat uap air di lapisan awan dalam, tetapi tidak ada permukaan padat untuk menampung genangan air.',
      radiationAndMagnetism: 'Memiliki sabuk radiasi mematikan dan medan magnet raksasa yang 20.000 kali lebih kuat dari medan magnet Bumi.',
      mainObstacleOrSupport: 'Ketiadaan permukaan padat dan tekanan gas hidrogen metalik yang mengompresi atom pada level ekstrem.'
    },
    benefitsAndFacts: {
      solarSystemRole: 'Berfungsi sebagai "Penyedot Debu Kosmis" raksasa yang gravitasinya menarik atau melontarkan komet dan asteroid bahaya agar tidak menabrak Bumi.',
      magneticFieldFunction: 'Menghasilkan ekor magnetosfer raksasa yang membentang hampir hingga orbit planet Saturnus.',
      uniqueFacts: [
        'Bintik Merah Besar (Great Red Spot) adalah badai antisiklon raksasa yang ukurannya cukup besar untuk menelan 1,3 planet Bumi sekaligus.',
        'Meskipun merupakan planet terbesar, Jupiter berputar pada porosnya paling cepat (1 hari hanya ~10 jam), menyebabkan bentuknya agak pepat di kutub.',
        'Ganymede, salah satu bulan Jupiter, adalah bulan terbesar di Tata Surya—bahkan lebih besar dari planet Merkurius.'
      ]
    },
    color: '#d6b896',
    secondaryColor: '#a86539',
    radiusScale: 2.5,
    orbitDistance: 37,
    orbitSpeed: 0.009,
    rotationSpeed: 0.03,
    textureType: 'jupiter'
  },
  {
    id: 'saturn',
    name: 'Saturn',
    indonesianName: 'Saturnus',
    orderFromSun: 6,
    type: 'Raksasa Gas',
    tagline: 'Permata Bermahkota Cincin Spektakuler',
    overview: 'Saturnus terkenal di seluruh alam semesta berkat sistem cincinnya yang megah dan rumit, tersusun dari miliaran bongkahan es air murni dan batuan kosmik. Planet ini memiliki kerapatan terendah—bisa terapung di atas air!',
    diameterKm: 116460,
    diameterFormatted: '116.460 km (9,14 × Bumi)',
    massKg: '5,683 × 10²⁶ kg (95,2 × Bumi)',
    distanceFromSunMillionKm: 1433.5,
    distanceFormatted: '1,43 miliar km (9,58 SA)',
    surfaceTempCelsius: '-140 °C (Lapisan Awan)',
    rotationPeriod: '10 jam 33 menit',
    revolutionPeriod: '29,45 tahun Bumi',
    axialTiltDeg: 26.73,
    naturalSatellitesCount: 146, // Pemegang rekor satelit terbanyak (termasuk Titan & Enceladus)
    gravityMps2: 10.44,
    composition: ['Hidrogen (96%)', 'Helium (3%)', 'Metana & Amonia'],
    lifePotential: {
      status: 'Tidak Layak (Bulannya Titan & Enceladus Sangat Berpotensi)',
      summary: 'Planet itu sendiri adalah bola gas bertekanan luar biasa, namun bulannya Titan memiliki atmosfer tebal dan danau metana cair, serta Enceladus menyemburkan geiser samudra air asin.',
      atmosphere: 'Gas hidrogen dan helium dengan kabut fotokimia berwarna kuning mentega dan badai heksagon di kutub utara.',
      waterPresence: 'Di planet utama berupa kristal uap beku, tetapi cincinnya tersusun dari 99% partikel es air murni.',
      radiationAndMagnetism: 'Medan magnet stabil dan simetris terhadap poros rotasinya, mengurung partikel bermuatan dalam sabuk radiasi.',
      mainObstacleOrSupport: 'Kurangnya permukaan padat dan suhu beku ekstrem di angkasa luar.'
    },
    benefitsAndFacts: {
      solarSystemRole: 'Bersama Jupiter, gravitasi Saturnus menyeimbangkan kestabilan orbit seluruh planet luar dan sabuk Kuiper.',
      magneticFieldFunction: 'Menjaga interaksi partikel ion dengan cincin dan menghasilkan aurora ultraviolet di kutubnya.',
      uniqueFacts: [
        'Saturnus adalah satu-satunya planet di Tata Surya yang kerapatan rata-ratanya lebih rendah dari air (0,687 g/cm³)—ia akan mengapung jika ada bak mandi raksasa!',
        'Sistem cincinnya membentang selebar 282.000 km, namun ketebalannya sangat tipis—hanya sekitar 10 hingga 30 meter saja!',
        'Di kutub utara Saturnus terdapat pola badai heksagonal (segi enam) raksasa permanen yang tidak ditemukan di planet lain mana pun.'
      ]
    },
    color: '#e2ce9f',
    secondaryColor: '#c7b282',
    radiusScale: 2.1,
    orbitDistance: 48,
    orbitSpeed: 0.007,
    rotationSpeed: 0.026,
    hasRings: true,
    ringInnerRadius: 2.6,
    ringOuterRadius: 4.8,
    textureType: 'saturn'
  },
  {
    id: 'uranus',
    name: 'Uranus',
    indonesianName: 'Uranus',
    orderFromSun: 7,
    type: 'Raksasa Es',
    tagline: 'Raksasa Es yang Menggelinding Miring di Orbitnya',
    overview: 'Uranus adalah raksasa es berwarna toska kebiruan dengan kemiringan poros rotasi ekstrem 98 derajat, membuatnya seolah "menggelinding" menyusuri jalur orbitnya mengitari Matahari.',
    diameterKm: 50724,
    diameterFormatted: '50.724 km (3,98 × Bumi)',
    massKg: '8,681 × 10²⁵ kg (14,5 × Bumi)',
    distanceFromSunMillionKm: 2872.5,
    distanceFormatted: '2,87 miliar km (19,2 SA)',
    surfaceTempCelsius: '-224 °C (Planet dengan Atmosfer Terdingin)',
    rotationPeriod: '17 jam 14 menit (Rotasi Retrograde)',
    revolutionPeriod: '84 tahun Bumi',
    axialTiltDeg: 97.77, // Berputar miring hampir rebah
    naturalSatellitesCount: 28, // Termasuk Miranda, Ariel, Umbriel, Titania, Oberon
    gravityMps2: 8.69,
    composition: ['Air, Metana & Amonia Beku (Mantel Es 80%)', 'Hidrogen & Helium (Atmosfer)', 'Inti Batuan Silikat'],
    lifePotential: {
      status: 'Sangat Mustahil',
      summary: 'Lingkungan es beku ekstrem tanpa sumber panas internal yang memadai bagi metabolisme biologis.',
      atmosphere: 'Mengandung gas metana yang menyerap cahaya merah dan memantulkan rona hijau kebiruan (sian).',
      waterPresence: 'Tersimpan dalam wujud "fluida superkritis panas-beku padat" (es bertekanan masif) di dalam mantelnya.',
      radiationAndMagnetism: 'Medan magnetnya unik dan aneh: miring 59 derajat dari poros rotasi dan bergeser dari titik tengah planet.',
      mainObstacleOrSupport: 'Suhu beku -224 °C dan siklus malam/siang ekstrem selama 42 tahun berturut-turut di setiap kutub.'
    },
    benefitsAndFacts: {
      solarSystemRole: 'Mengikat sabuk es trans-Neptunian dan menyeimbangkan dinamika gravitasi keluarga raksasa es.',
      magneticFieldFunction: 'Membentuk magnetosfer yang berputar seperti pembuka sumbat botol (corkscrew) saat planet bergerak maju.',
      uniqueFacts: [
        'Karena sumbunya miring hampir 98 derajat, Uranus mengalami malam musim dingin selama 42 tahun dan siang musim panas selama 42 tahun tanpa henti!',
        'Uranus adalah planet pertama yang ditemukan menggunakan teleskop astronomi modern oleh William Herschel pada tahun 1781.',
        'Memiliki 13 cincin tipis yang redup dan gelap, yang tersusun dari debu organik kosmis purba.'
      ]
    },
    color: '#8be5e8',
    secondaryColor: '#5ec3c7',
    radiusScale: 1.6,
    orbitDistance: 59,
    orbitSpeed: 0.005,
    rotationSpeed: -0.016,
    hasRings: true,
    ringInnerRadius: 2.0,
    ringOuterRadius: 2.6,
    textureType: 'uranus'
  },
  {
    id: 'neptune',
    name: 'Neptune',
    indonesianName: 'Neptunus',
    orderFromSun: 8,
    type: 'Raksasa Es',
    tagline: 'Dunia Biru Kobalt & Raja Badai Tercepat Kosmis',
    overview: 'Neptunus adalah planet terjauh dari Matahari dalam sistem tata surya kita. Memiliki warna biru laut pekat yang spektakuler dengan angin badai supersonik yang melesat lebih cepat dari kecepatan suara di Bumi.',
    diameterKm: 49244,
    diameterFormatted: '49.244 km (3,86 × Bumi)',
    massKg: '1,024 × 10²⁶ kg (17,1 × Bumi)',
    distanceFromSunMillionKm: 4495.1,
    distanceFormatted: '4,49 miliar km (30,07 SA)',
    surfaceTempCelsius: '-214 °C',
    rotationPeriod: '16 jam 6 menit',
    revolutionPeriod: '164,8 tahun Bumi',
    axialTiltDeg: 28.32,
    naturalSatellitesCount: 16, // Termasuk Triton yang mengorbit mundur
    gravityMps2: 11.15,
    composition: ['Mantel Es Air, Amonia, Metana (80%)', 'Atmosfer Hidrogen & Helium', 'Inti Berbatu'],
    lifePotential: {
      status: 'Sangat Mustahil',
      summary: 'Angin badai ganas supersonik dan ketiadaan sinar matahari hangat membuat lingkungan mustahil menopang metabolisme biologis terestrial.',
      atmosphere: 'Kaya gas metana yang memberikan rona biru kobalt terang, dihiasi awan sirus putih kristal es metana.',
      waterPresence: 'Tersimpan dalam jumlah sangat besar sebagai mantel lumpur es bertekanan tinggi di sekeliling inti batu.',
      radiationAndMagnetism: 'Medan magnetnya tertekuk miring 47 derajat dan mengalami fluktuasi liar di setiap rotasinya.',
      mainObstacleOrSupport: 'Jarak 4,5 miliar km dari Matahari menghasilkan intensitas sinar surya 900 kali lebih redup daripada di Bumi.'
    },
    benefitsAndFacts: {
      solarSystemRole: 'Penjaga perbatasan terluar yang gravitasinya mengatur orbit objek Sabuk Kuiper dan planet kerdil Pluto.',
      magneticFieldFunction: 'Menciptakan fenomena fluks magnetik asimetris yang dinamis di ruang antariksa terluar.',
      uniqueFacts: [
        'Neptunus memiliki angin tercepat di Tata Surya, bertiup hingga kecepatan mencengangkan 2.100 km/jam (hampir Mach 2).',
        'Neptunus adalah satu-satunya planet yang ditemukan melalui perhitungan matematika sebelum diamati secara fisik lewat teleskop.',
        'Bulannya yang terbesar, Triton, mengorbit dengan arah berlawanan (gerak retrograde) dan memiliki geiser nitrogen cair aktif yang menyembur ke angkasa.'
      ]
    },
    color: '#3b67cc',
    secondaryColor: '#1d3f94',
    radiusScale: 1.55,
    orbitDistance: 70,
    orbitSpeed: 0.0035,
    rotationSpeed: 0.018,
    textureType: 'neptune'
  }
];
